// Web Audio API V8 Twin-Turbo Synthesizer for Throttle Rev Simulator

class EngineSoundSynthesizer {
  private ctx: AudioContext | null = null;
  private osc1: OscillatorNode | null = null;
  private osc2: OscillatorNode | null = null;
  private gainNode: GainNode | null = null;
  private filterNode: BiquadFilterNode | null = null;
  private isMuted: boolean = false;
  private isPlaying: boolean = false;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (this.gainNode && this.ctx) {
      this.gainNode.gain.setValueAtTime(muted ? 0 : 0.28, this.ctx.currentTime);
    }
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public revEngine(rpm: number) {
    if (this.isMuted) return;
    try {
      this.initContext();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      // Map RPM (800 - 9000) to fundamental firing frequency (approx 35Hz to 320Hz)
      const baseFreq = 38 + ((rpm - 800) / 8200) * 280;

      if (!this.isPlaying) {
        this.gainNode = this.ctx.createGain();
        this.filterNode = this.ctx.createBiquadFilter();
        this.filterNode.type = 'lowpass';
        this.filterNode.frequency.setValueAtTime(450, now);
        this.filterNode.Q.setValueAtTime(4.2, now);

        this.osc1 = this.ctx.createOscillator();
        this.osc1.type = 'sawtooth';
        this.osc2 = this.ctx.createOscillator();
        this.osc2.type = 'triangle';

        this.osc1.connect(this.filterNode);
        this.osc2.connect(this.filterNode);
        this.filterNode.connect(this.gainNode);
        this.gainNode.connect(this.ctx.destination);

        this.gainNode.gain.setValueAtTime(0.01, now);
        this.gainNode.gain.exponentialRampToValueAtTime(0.24, now + 0.04);

        this.osc1.start();
        this.osc2.start();
        this.isPlaying = true;
      }

      if (this.osc1 && this.osc2 && this.filterNode) {
        this.osc1.frequency.setTargetAtTime(baseFreq, now, 0.05);
        // Sub-harmonic rumble (V8 crossplane rumble)
        this.osc2.frequency.setTargetAtTime(baseFreq * 0.5, now, 0.05);

        // Exhaust pop/rasp resonance near redline
        const filterCutoff = 350 + ((rpm - 800) / 8200) * 1600;
        this.filterNode.frequency.setTargetAtTime(filterCutoff, now, 0.05);
      }
    } catch {
      // Audio context blocked or unsupported
    }
  }

  public stopRev() {
    if (!this.isPlaying || !this.ctx || !this.gainNode) return;
    const now = this.ctx.currentTime;
    try {
      this.gainNode.gain.setTargetAtTime(0.001, now, 0.12);
      setTimeout(() => {
        if (this.osc1) {
          this.osc1.stop();
          this.osc1.disconnect();
          this.osc1 = null;
        }
        if (this.osc2) {
          this.osc2.stop();
          this.osc2.disconnect();
          this.osc2 = null;
        }
        this.isPlaying = false;
      }, 160);
    } catch {
      this.isPlaying = false;
    }
  }

  // Backfire pop when dropping off throttle from high RPM
  public triggerExhaustPop() {
    if (this.isMuted || !this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const popOsc = this.ctx.createOscillator();
      const popGain = this.ctx.createGain();
      popOsc.type = 'sawtooth';
      popOsc.frequency.setValueAtTime(140, now);
      popOsc.frequency.exponentialRampToValueAtTime(45, now + 0.09);

      popGain.gain.setValueAtTime(0.35, now);
      popGain.gain.exponentialRampToValueAtTime(0.001, now + 0.11);

      popOsc.connect(popGain);
      popGain.connect(this.ctx.destination);
      popOsc.start(now);
      popOsc.stop(now + 0.12);
    } catch {
      // ignore
    }
  }
}

export const engineSound = new EngineSoundSynthesizer();
