import React, { useState } from 'react';
import {
  X,
  Cpu,
  Wrench,
  AlertTriangle,
  Gauge,
  Search,
  Sparkles,
  Zap,
  Car,
} from 'lucide-react';

export interface DiagnosticModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialCode?: string;
}

interface DiagnosticCodeData {
  code: string;
  category: 'Powertrain المحرك وناقل الحركة' | 'Chassis الهيكل والمكابح' | 'Network شبكة CAN-Bus';
  titleAr: string;
  titleEn: string;
  severity: 'حرج للغاية (Redline)' | 'متوسط (Amber)' | 'تحذيري صيانة';
  symptoms: string[];
  rootCauses: string[];
  torqueSpec: string;
  estimatedFixTime: string;
  proTip: string;
}

const DTC_DATABASE: DiagnosticCodeData[] = [
  {
    code: 'P0299',
    category: 'Powertrain المحرك وناقل الحركة',
    titleAr: 'نقص ضغط التوربو (Turbocharger Underboost Condition)',
    titleEn: 'Turbocharger / Supercharger Underboost',
    severity: 'متوسط (Amber)',
    symptoms: [
      'فقدان ملحوظ في تسارع المركبة فوق 3,200 دورة/دقيقة',
      'صوت صفير غير طبيعي من خراطيم الإنترکولر (Boost Leak)',
      'دخول المحرك في وضع الحماية Limp Mode في بعض الطرازات',
    ],
    rootCauses: [
      'تسرّب في خراطيم ضغط الهواء بين التوربو والإنترکولر أو صمام الـ Blow-Off',
      'تآكل أو خلل في صمام التحكم في عادم التوربو (Wastegate Actuator)',
      'انسداد جزئي في المحول الحفاز (Catalytic Converter) يقلل دوران التوربين',
    ],
    torqueSpec: 'مرابط خراطيم التوربو المصنوعة من الفولاذ: 6.5 Nm ± 0.5 | براغي الـ Wastegate: 14 Nm',
    estimatedFixTime: '45 - 90 دقيقة فحص وإصلاح',
    proTip: 'ابدأ دائماً باختبار تسريب الدخان (Smoke Test) عند ضغط 15 PSI قبل استبدال شاحن التوربو الغالي.',
  },
  {
    code: 'P0300',
    category: 'Powertrain المحرك وناقل الحركة',
    titleAr: 'إشعال مفقود عشوائي/متعدد في أسطوانات المحرك (Random Misfire)',
    titleEn: 'Random/Multiple Cylinder Misfire Detected',
    severity: 'حرج للغاية (Redline)',
    symptoms: [
      'اهتزاز قوي ورجفان في المحرك عند السرعة الخاملة (Idle)',
      'وميض ضوء فحص المحرك (Check Engine Flashing) عند التسارع',
      'رائحة وقود غير محترق من العادم مع ارتفاع حرارة العادم',
    ],
    rootCauses: [
      'بواجي شمعات الإشعال (Spark Plugs) متآكلة أو فجوتها غير صحيحة',
      'كويلات الإشعال (Ignition Coils) ضعيفة تحت الحمل العالي',
      'بخاخات وقود مسدودة أو ضعف في مضخة الوقود عالية الضغط (HPFP)',
    ],
    torqueSpec: 'بواجي الإشعال (M12x1.25): 23 Nm (بدون شحم على السن) | براغي كويلات الإشعال: 8 Nm',
    estimatedFixTime: '30 - 60 دقيقة',
    proTip: 'قم بتبديل كويل الإشعال المشتبه به مع أسطوانة مجاورة؛ إذا انتقل كود العطل (مثل P0301 إلى P0302) فالكويل هو السبب قطعاً.',
  },
  {
    code: 'P0171',
    category: 'Powertrain المحرك وناقل الحركة',
    titleAr: 'خليط الوقود فقير جداً في الضفة 1 (System Too Lean Bank 1)',
    titleEn: 'Air/Fuel Mixture System Too Lean (Bank 1)',
    severity: 'متوسط (Amber)',
    symptoms: [
      'تذبذب عداد الـ RPM عند الوقوف الخامل',
      'قراءة الـ Long Term Fuel Trim تتجاوز +15%',
      'فرقعة خفيفة (Backfire) في مجمع السحب عند الضغط الفجائي',
    ],
    rootCauses: [
      'تسريب هواء غير محسوب (Vacuum Leak) بعد حساس الهواء MAF',
      'اتساخ سلك حساس تدفق الهواء (MAF Sensor) برذاذ زيت الفلتر الرياضي',
      'انخفاض ضغط طرمبة البنزين تحت 55 PSI',
    ],
    torqueSpec: 'براغي ثلاجة السحب (Intake Manifold Bolts): 11 Nm بنمط نجمي متقاطع',
    estimatedFixTime: '40 دقيقة فحص',
    proTip: 'راقب قراءة حساس الأوكسجين العريض O2 Wideband وقراءات الـ STFT/LTFT في الرسم البياني المباشر.',
  },
  {
    code: 'P0011',
    category: 'Powertrain المحرك وناقل الحركة',
    titleAr: 'توقيت عمود الكامات متقدم أكثر من اللازم (VVT Timing Over-Advanced)',
    titleEn: 'Intake Camshaft Position Timing Over-Advanced Bank 1',
    severity: 'حرج للغاية (Redline)',
    symptoms: [
      'صوت طقطقة معدنية خفيفة عند تشغيل المحرك بارداً',
      'فقدان عزم الدوران في السرعات المنخفضة والمتوسطة',
      'استهلاك وقود أعلى من المعتاد بـ 12-18%',
    ],
    rootCauses: [
      'انسداد فلتر صمام التحكم بالزيت (OCV / VVT Solenoid Screen) برواسب الزيت القديم',
      'انخفاض لزوجة أو ضغط زيت المحرك التخليقي',
      'استطالة خفيفة في جنزير التوقيت (Timing Chain Stretch)',
    ],
    torqueSpec: 'صمام التحكم في التوقيت VVT Solenoid Bolt: 10 Nm | حساس الكامات: 8.5 Nm',
    estimatedFixTime: '50 دقيقة',
    proTip: 'استخدم دائماً درجة لزوجة الزيت الموصى بها من المصنع (مثال 0W-40 أو 5W-30 Full Synthetic) ونظف شبكة صمام الـ VVT.',
  },
  {
    code: 'U0100',
    category: 'Network شبكة CAN-Bus',
    titleAr: 'انقطاع الاتصال مع وحدة تحكم المحرك (Lost Communication With ECM/PCM)',
    titleEn: 'High-Speed CAN-Bus Communication Lost With ECM',
    severity: 'حرج للغاية (Redline)',
    symptoms: [
      'عدم استجابة بادئ الحركة (No-Crank No-Start)',
      'إضاءة جميع مؤشرات التحذير (ABS, Traction, Check Engine) في لوحة القيادة',
      'توقف عداد الـ RPM عن القراءة الفورية',
    ],
    rootCauses: [
      'تآكل أو أكسدة في خط التأريض الرئيسي (Chassis Ground Strap G101/G104)',
      'قطع أو تماس في خطي شبكة الـ CAN High (سلك أصفر 60 أوم) أو CAN Low',
      'تلف في ريليه الطاقة الرئيسي (Main EFI/ECU Relay)',
    ],
    torqueSpec: 'برغي تأريض الشاصي الرئيسي M8: 18 Nm (بعد كشط الطلاء لضمان التماس النقي)',
    estimatedFixTime: '60 - 120 دقيقة فحص كهربائي بالمقاييس',
    proTip: 'قس المقاومة بين المنفذين 6 و 14 في فيشة OBD-II؛ القراءة السليمة يجب أن تكون 60 أوم بالضبط (مقاومتا نهاية 120 أوم على التوازي).',
  },
];

export const DiagnosticModal: React.FC<DiagnosticModalProps> = ({
  isOpen,
  onClose,
  initialCode,
}) => {
  const [searchQuery, setSearchQuery] = useState(initialCode || 'P0299');
  const [selectedCode, setSelectedCode] = useState<DiagnosticCodeData>(
    DTC_DATABASE.find((c) => c.code === initialCode) || DTC_DATABASE[0]
  );
  const [customVinEngine, setCustomVinEngine] = useState('VR38DETT / Porsche 9A2 Evo');

  if (!isOpen) return null;

  const filteredCodes = DTC_DATABASE.filter(
    (item) =>
      item.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.titleAr.includes(searchQuery) ||
      item.titleEn.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md animate-fadeIn"
      role="dialog"
      aria-modal="true"
      aria-labelledby="diagnostic-modal-title"
    >
      <div className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto bg-[#14161D] border border-white/12 rounded-2xl shadow-2xl glow-crimson-sm text-right">
        {/* Top Telemetry Header Bar */}
        <div className="sticky top-0 z-20 flex items-center justify-between px-6 py-4 border-b border-white/10 bg-[#14161D]/95 backdrop-blur-xl">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#E60012]/15 border border-[#E60012]/40 text-[#E60012]">
              <Cpu className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/15 px-2.5 py-0.5 text-xs font-telemetry text-emerald-400 border border-emerald-500/30">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  OBD-II CAN-BUS LIVE
                </span>
                <select
                  value={customVinEngine}
                  onChange={(e) => setCustomVinEngine(e.target.value)}
                  className="text-xs text-gray-300 bg-[#090A0D] border border-white/12 rounded-md px-2 py-0.5 font-telemetry focus:outline-none focus:border-[#E60012]"
                >
                  <option value="VR38DETT / Porsche 9A2 Evo">VR38DETT / Porsche 9A2 Evo</option>
                  <option value="BMW S58B30T0 TwinTurbo M4">BMW S58B30T0 TwinTurbo M4</option>
                  <option value="Toyota 2JZ-GTE / 1FZ-FE Land Cruiser">Toyota 2JZ-GTE / 1FZ-FE</option>
                  <option value="Chevy LS3 6.2L V8 Supercharged">Chevy LS3 6.2L V8 Supercharged</option>
                </select>
              </div>
              <h3 id="diagnostic-modal-title" className="text-lg font-bold text-white font-heading">
                محلل الأكواد الهندسي الذكي (APEX DTC Diagnostic Studio)
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white transition-colors"
            aria-label="إغلاق النافذة"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Search & Code Selector Bar */}
        <div className="p-6 border-b border-white/8 bg-[#090A0D]/60">
          <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
            <div className="relative flex-1">
              <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث بكود العطل (مثال: P0299, P0300, P0171, U0100)..."
                className="w-full rounded-xl bg-[#14161D] border border-white/12 pr-10 pl-4 py-2.5 text-sm text-white placeholder-gray-500 font-telemetry focus:outline-none focus:border-[#E60012] transition-colors"
              />
            </div>
            <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0">
              {DTC_DATABASE.map((item) => (
                <button
                  key={item.code}
                  onClick={() => setSelectedCode(item)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-telemetry font-bold transition-all shrink-0 ${
                    selectedCode.code === item.code
                      ? 'bg-[#E60012] text-white shadow-lg shadow-[#E60012]/30'
                      : 'bg-white/5 text-gray-300 hover:bg-white/10 border border-white/10'
                  }`}
                >
                  {item.code}
                </button>
              ))}
            </div>
          </div>

          {filteredCodes.length === 0 && (
            <div className="mt-3 text-xs text-amber-400 flex items-center gap-1.5">
              <AlertTriangle className="h-4 w-4" />
              لم يتم العثور على الكود في العينة التجريبية السريعة — متوفر +45,000 كود معتمد بالذكاء الاصطناعي في باقة المنصة الكاملة.
            </div>
          )}
        </div>

        {/* Selected Diagnostic Details Panel */}
        <div className="p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-xl bg-gradient-to-l from-[#E60012]/15 via-white/[0.03] to-transparent border border-[#E60012]/30">
            <div>
              <div className="flex items-center gap-2.5 mb-1.5">
                <span className="px-2.5 py-1 rounded-md bg-[#E60012] text-white font-telemetry font-bold text-sm tracking-wider">
                  DTC {selectedCode.code}
                </span>
                <span
                  className={`px-2.5 py-0.5 rounded-full text-xs font-medium border ${
                    selectedCode.severity.includes('حرج')
                      ? 'bg-red-500/20 text-red-300 border-red-500/40'
                      : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  }`}
                >
                  {selectedCode.severity}
                </span>
                <span className="text-xs text-gray-400">{selectedCode.category}</span>
              </div>
              <h4 className="text-xl font-bold text-white font-heading">
                {selectedCode.titleAr}
              </h4>
              <p className="text-xs text-gray-400 font-telemetry mt-0.5">
                {selectedCode.titleEn}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <div className="text-left bg-[#090A0D] px-4 py-2 rounded-xl border border-white/10">
                <div className="text-[11px] text-gray-400">زمن الإصلاح المقدر</div>
                <div className="text-sm font-bold text-amber-400 font-telemetry">
                  {selectedCode.estimatedFixTime}
                </div>
              </div>
            </div>
          </div>

          {/* 3-Column Diagnostic Breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Symptoms */}
            <div className="p-5 rounded-xl bg-[#090A0D]/80 border border-white/8">
              <div className="flex items-center gap-2 mb-3 text-amber-400">
                <AlertTriangle className="h-4 w-4" />
                <h5 className="font-bold text-sm font-heading">الأعراض الظاهرة على المحرك</h5>
              </div>
              <ul className="space-y-2.5">
                {selectedCode.symptoms.map((symptom, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-gray-300">
                    <span className="h-1.5 w-1.5 rounded-full bg-[#E60012] mt-2 shrink-0" />
                    <span>{symptom}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Root Causes */}
            <div className="p-5 rounded-xl bg-[#090A0D]/80 border border-white/8">
              <div className="flex items-center gap-2 mb-3 text-[#E60012]">
                <Wrench className="h-4 w-4" />
                <h5 className="font-bold text-sm font-heading">المسببات الهندسية الأكثر ترجيحاً</h5>
              </div>
              <ul className="space-y-2.5">
                {selectedCode.rootCauses.map((cause, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-gray-300">
                    <span className="flex h-4 w-4 items-center justify-center rounded-full bg-white/10 text-[10px] font-telemetry text-white shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span>{cause}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Torque Specifications & Master Technician Pro Tip */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2 p-4 rounded-xl bg-gradient-to-r from-amber-500/10 via-[#090A0D] to-[#090A0D] border border-amber-500/30 flex items-start gap-3.5">
              <div className="p-2.5 rounded-lg bg-amber-500/20 text-amber-400 shrink-0">
                <Sparkles className="h-5 w-5" />
              </div>
              <div>
                <span className="text-xs font-bold text-amber-400 uppercase font-telemetry block mb-1">
                  نصيحة كبير مهندسي أبِيكْس (MASTER TECH TIP)
                </span>
                <p className="text-xs sm:text-sm text-gray-200 leading-relaxed">
                  {selectedCode.proTip}
                </p>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#090A0D] border border-white/12 flex flex-col justify-between">
              <div className="flex items-center justify-between text-xs text-gray-400 mb-2">
                <span className="flex items-center gap-1.5">
                  <Gauge className="h-4 w-4 text-[#E60012]" />
                  عزم الربط الدقيق (Torque Spec)
                </span>
                <span className="font-telemetry text-emerald-400 text-[11px]">ISO 6789</span>
              </div>
              <div className="text-xs font-telemetry font-bold text-white leading-relaxed">
                {selectedCode.torqueSpec}
              </div>
            </div>
          </div>

          {/* Bottom Action Footer */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-white/10">
            <div className="flex items-center gap-2 text-xs text-gray-400">
              <Car className="h-4 w-4 text-gray-400" />
              <span>متاح مخطط التوصيل الكهربائي 3D الكامل لهذا العطل داخل المنصة</span>
            </div>
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <a
                href="#pricing"
                onClick={onClose}
                className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#E60012] hover:bg-[#c9000f] text-white text-xs sm:text-sm font-bold transition-all shadow-lg shadow-[#E60012]/25"
              >
                <Zap className="h-4 w-4" />
                افتح المخطط الهندسي الكامل مجاناً
              </a>
              <button
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 text-xs sm:text-sm transition-colors"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
