import React, { useState } from 'react';
import { Star, ShieldCheck, Quote, Award, CheckCircle2 } from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  const [filter, setFilter] = useState<'all' | 'pro' | 'enthusiast'>('all');

  const testimonials = [
    {
      category: 'pro',
      name: 'المهندس طارق الدوسري',
      role: 'مؤسس ورشة Apex Tuning Lab • الرياض',
      car: 'Porsche 911 GT3 RS / Nissan GT-R R35',
      dynoResult: 'اختصار 75% من وقت تتبع الأسلاك',
      text: 'في مركزنا نتعامل مع سيارات بورش ونيسان GT-R بقوة تتجاوز 1,200 حصان. ميزة مخططات الـ Pinout وعزم ربط المصنع في أبِيكْس ميكانيكا أنقذت فريقنا في تشخيص عطل شبكة CAN-Bus معقد خلال 20 دقيقة بدلاً من يومين كاملين.',
      rating: 5,
      verifiedDate: 'أبريل 2026 • اشتراك مركز أداء سنوي',
    },
    {
      category: 'enthusiast',
      name: 'سلطان بن حمود العتيبي',
      role: 'هاوي تعديل وبطل حلبة الدرفت • دبي',
      car: 'Toyota Supra 2JZ-GTE Single Turbo 910 WHP',
      dynoResult: '+910 WHP معايرة داينو آمنة',
      text: 'كنت أعتمد على المنتديات الأجنبية القديمة للبحث عن عزم ربط مسامير ARP ومخطط الفاكيوم لمحرك 2JZ. اليوم في جوالي داخل القراج أفتح المخطط التفاعلي 3D وأعرف كل تفصيلة بدقة. المنصة تحفة حقيقية لكل عاشق سيارات عربي.',
      rating: 5,
      verifiedDate: 'مارس 2026 • باقة الهاوي المحترف',
    },
    {
      category: 'pro',
      name: 'م. فيصل بن عبد العزيز القحطاني',
      role: 'كبير مهندسي تشخيص إلكترونيات السيارات • الدمام',
      car: 'BMW M4 S58 / Mercedes-AMG C63S',
      dynoResult: 'دقة 99.8% في أكواد ISTA/XENTRY',
      text: 'محلل الأكواد بالذكاء الاصطناعي لا يعطيك فقط ترجمة الكود، بل يعطيك قراءة الأوسيلوسكوب السليمة لموجة الحساس ويشرح لك خطوة بخطوة أي سلك تقيسه. خدمة العملاء والدعم الفني الهندسي لا يُعلى عليهما.',
      rating: 5,
      verifiedDate: 'أبريل 2026 • اشتراك ورشة احترافية',
    },
  ];

  const filteredTestimonials =
    filter === 'all'
      ? testimonials
      : testimonials.filter((t) => t.category === filter);

  return (
    <section id="testimonials" className="relative py-24 bg-[#090A0D] border-t border-white/10 overflow-hidden">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="text-right">
            <span className="inline-flex items-center gap-2 rounded-full bg-[#14161D] border border-white/12 px-3.5 py-1 text-xs font-telemetry font-bold text-amber-400 mb-3">
              <Award className="h-3.5 w-3.5" />
              <span>شهادات حقيقية من نخبة المحركات</span>
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-heading tracking-tight">
              موثوق من أبطال الحلبات ومراكز الصيانة
            </h2>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-2 bg-[#14161D] p-1 rounded-xl border border-white/12 self-start md:self-auto">
            {[
              { id: 'all', label: 'جميع الآراء' },
              { id: 'pro', label: 'الميكانيكيون والورش' },
              { id: 'enthusiast', label: 'عشاق التعديل' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setFilter(tab.id as 'all' | 'pro' | 'enthusiast')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  filter === tab.id
                    ? 'bg-[#E60012] text-white shadow-md'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* 3-Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {filteredTestimonials.map((item, idx) => (
            <div
              key={idx}
              className="relative rounded-2xl bg-[#14161D]/90 border border-white/12 p-7 hover:border-[#E60012]/50 transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Top Badge & Stars */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-1 text-amber-400">
                    {[...Array(item.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-amber-400" />
                    ))}
                  </div>
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-[11px] font-telemetry font-bold text-emerald-400">
                    <CheckCircle2 className="h-3 w-3" />
                    {item.dynoResult}
                  </span>
                </div>

                <Quote className="h-7 w-7 text-[#E60012]/40 mb-3" />

                <p className="text-sm text-gray-200 leading-relaxed mb-6">
                  &ldquo;{item.text}&rdquo;
                </p>
              </div>

              {/* Author Info */}
              <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                <div>
                  <div className="font-heading font-bold text-white text-base">
                    {item.name}
                  </div>
                  <div className="text-xs text-gray-400 mt-0.5">{item.role}</div>
                  <div className="text-[11px] font-telemetry text-amber-400 mt-1">
                    {item.car}
                  </div>
                </div>

                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 border border-white/10 text-emerald-400" title="مشترك موثق">
                  <ShieldCheck className="h-5 w-5" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
