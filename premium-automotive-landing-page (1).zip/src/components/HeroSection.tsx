import React, { useState } from 'react';
import {
  Zap,
  Cpu,
  ChevronLeft,
  Flame,
  ShieldCheck,
  Activity,
  Play,
} from 'lucide-react';
import { engineSound } from '../utils/engineSound';

interface HeroSectionProps {
  onOpenDiagnostic: (code?: string) => void;
  onOpenSignup: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onOpenDiagnostic,
  onOpenSignup,
}) => {
  // Throttle Rev Simulator state (800 RPM idle to 9000 RPM redline)
  const [rpm, setRpm] = useState(1150);
  const [isRevving, setIsRevving] = useState(false);
  const [gear, setGear] = useState<'N' | '2' | '3' | '4' | '5' | '6'>('3');

  // Calculated dynamic telemetry based on current RPM
  const calcHp = Math.round(110 + (rpm - 800) * 0.082 - Math.pow(Math.max(0, rpm - 8200), 1.6) * 0.12);
  const calcTorque = Math.round(
    290 + 640 * Math.sin(((Math.min(rpm, 7200) - 800) / 6400) * Math.PI)
  );
  const calcBoostPsi = (Math.max(0, (rpm - 2200) / 5800) * 28.4).toFixed(1);
  const calcOilTemp = Math.round(92 + (rpm / 9000) * 16);
  const calcAfr = rpm > 6500 ? '11.4:1 (RICH)' : rpm > 3800 ? '12.6:1 (POWER)' : '14.7:1 (STOICH)';

  // Shift LED bars calculation (10 LEDs)
  const activeLeds = Math.min(10, Math.floor(((rpm - 3500) / 5200) * 10));

  // Handle manual slider or hold throttle
  const handleThrottleChange = (val: number) => {
    setRpm(val);
    engineSound.revEngine(val);
  };

  const handleLaunchControl = () => {
    setIsRevving(true);
    let step = 1150;
    const interval = setInterval(() => {
      step = step + 650;
      if (step >= 8700) {
        step = 8700;
        engineSound.triggerExhaustPop();
      }
      setRpm(step);
      engineSound.revEngine(step);
    }, 70);

    setTimeout(() => {
      clearInterval(interval);
      setIsRevving(false);
      setRpm(1800);
      engineSound.stopRev();
    }, 1900);
  };

  // Rotation angle for SVG Tachometer gauge needle (-125deg at 0 to +125deg at 9500 RPM)
  const needleAngle = -125 + (rpm / 9500) * 250;

  return (
    <section className="relative min-h-screen pt-28 pb-20 lg:pt-36 lg:pb-28 overflow-hidden flex items-center">
      {/* Volumetric Studio Backdrop Image with Carbon Vignette */}
      <div className="absolute inset-0 z-0">
        <img
          src="/images/hypercar-hero.jpg"
          alt="Hypercar Carbon Silhouette"
          className="w-full h-full object-cover object-center opacity-32 scale-105 transition-transform duration-1000"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#090A0D] via-[#090A0D]/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#090A0D] via-[#090A0D]/75 to-transparent" />
        {/* Carbon Weave Mesh Overlay */}
        <div className="absolute inset-0 bg-carbon-weave opacity-60" />
      </div>

      {/* Radial Rim Light Highlights */}
      <div className="pointer-events-none absolute -top-32 right-1/4 h-96 w-96 rounded-full bg-[#E60012]/15 blur-[120px]" />
      <div className="pointer-events-none absolute bottom-0 left-10 h-80 w-80 rounded-full bg-amber-500/10 blur-[110px]" />

      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-10 items-center">
          {/* Left Column: Arabic High-Conversion Copy & CTAs */}
          <div className="lg:col-span-7 space-y-7 text-right">
            {/* Top Telemetry Tag */}
            <div className="inline-flex items-center gap-2.5 rounded-full bg-[#14161D]/90 border border-white/15 px-4 py-1.5 backdrop-blur-xl shadow-lg">
              <span className="flex h-2 w-2 rounded-full bg-[#E60012] animate-ping" />
              <span className="text-xs font-telemetry font-bold text-amber-400 tracking-wide">
                APEX MECHANICA TELEMETRY OS v4.8
              </span>
              <span className="h-3 w-px bg-white/20" />
              <span className="text-xs text-gray-300 font-medium">
                لعشاق السيارات والمحترفين
              </span>
            </div>

            {/* Main Hero Headline */}
            <h1 className="text-4xl sm:text-5xl xl:text-6xl font-extrabold tracking-tight text-white leading-[1.22]">
              هندسة الأداء وشغف{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-l from-[#E60012] via-rose-500 to-amber-400">
                ميكانيك السيارات
              </span>{' '}
              بمعايير الحلبات الاحترافية
            </h1>

            {/* Sub-headline */}
            <p className="text-base sm:text-lg lg:text-xl text-gray-300 max-w-2xl leading-relaxed font-normal">
              المنصة المتكاملة الأولى عربياً التي تجمع{' '}
              <strong className="text-white font-bold">تشخيص الأعطال بالذكاء الاصطناعي وOBD-II</strong>، ومخططات المحركات ثلاثية الأبعاد، وجداول عزم الربط الدقيق، ومجتمع نخبوي من مهندسي وعشاق المحركات الفائقة.
            </p>

            {/* Dual CTAs & Guarantee Badges */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
              <button
                onClick={onOpenSignup}
                className="group relative inline-flex items-center justify-center gap-3 px-7 py-4 rounded-xl bg-[#E60012] hover:bg-[#D00010] text-white text-base font-bold transition-all glow-crimson active:scale-[0.98]"
              >
                <span>ابدأ رحلتك الاحترافية مجاناً</span>
                <ChevronLeft className="h-5 w-5 group-hover:-translate-x-1 transition-transform" />
              </button>

              <button
                onClick={() => onOpenDiagnostic('P0299')}
                className="inline-flex items-center justify-center gap-2.5 px-6 py-4 rounded-xl bg-[#14161D]/90 hover:bg-white/10 text-gray-200 border border-white/15 text-sm sm:text-base font-semibold transition-all backdrop-blur-xl"
              >
                <Cpu className="h-5 w-5 text-amber-400" />
                <span>جرّب كاشف الأكواد المباشر OBD-II</span>
              </button>
            </div>

            {/* Trust Mini Checkpoints */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-4 border-t border-white/10">
              <div className="flex items-center gap-2.5">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-400">
                  <ShieldCheck className="h-4 w-4" />
                </div>
                <div className="text-right">
                  <div className="text-xs font-bold text-white">+45,000 مخطط أصلي</div>
                  <div className="text-[11px] text-gray-400">OEM Wiring & Torque</div>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#E60012]/15 text-[#E60012]">
                  <Activity className="h-4 w-4" />
                </div>
                <div className="text-right">
                  <div className="text-xs font-bold text-white">99.4% دقة التشخيص</div>
                  <div className="text-[11px] text-gray-400">CAN-Bus Live DTC</div>
                </div>
              </div>

              <div className="col-span-2 sm:col-span-1 flex items-center gap-2.5">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-amber-500/15 text-amber-400">
                  <Flame className="h-4 w-4" />
                </div>
                <div className="text-right">
                  <div className="text-xs font-bold text-white">+18,500 مهندس وهاوي</div>
                  <div className="text-[11px] text-gray-400">نخبة ميكانيك الخليج والعرب</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Digital Tachometer & Throttle Rev Cockpit */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl bg-[#14161D]/95 border border-white/15 p-6 shadow-2xl backdrop-blur-2xl glow-crimson-sm">
              {/* Header Telemetry Bar */}
              <div className="flex items-center justify-between pb-4 mb-4 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <span className="flex h-2.5 w-2.5 rounded-full bg-[#E60012] animate-pulse" />
                  <span className="text-xs font-telemetry font-bold text-white">
                    LIVE DYNO COCKPIT SIMULATOR
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-white/5 border border-white/10 text-[11px] font-telemetry text-amber-400">
                    V8 TWIN-TURBO 4.0L
                  </span>
                  <button
                    onClick={handleLaunchControl}
                    disabled={isRevving}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#E60012]/20 hover:bg-[#E60012] text-[#E60012] hover:text-white border border-[#E60012]/40 text-xs font-telemetry font-bold transition-all"
                  >
                    <Play className="h-3 w-3" />
                    LAUNCH REV
                  </button>
                </div>
              </div>

              {/* F1 / Hypercar Shift LED Strip */}
              <div className="mb-4">
                <div className="flex items-center justify-between text-[11px] text-gray-400 font-telemetry mb-1.5">
                  <span>SHIFT LIGHTS TELEMETRY</span>
                  <span className={rpm > 8200 ? 'text-[#E60012] font-bold animate-pulse' : 'text-gray-400'}>
                    {rpm > 8200 ? 'REDLINE SHIFT NOW!' : 'OPTIMAL POWERBAND'}
                  </span>
                </div>
                <div className="grid grid-cols-10 gap-1.5 h-3">
                  {[...Array(10)].map((_, i) => {
                    const isActive = i < activeLeds;
                    const ledColor =
                      i < 5
                        ? 'bg-emerald-500 shadow-emerald-500/50'
                        : i < 8
                        ? 'bg-amber-400 shadow-amber-400/50'
                        : 'bg-[#E60012] shadow-[#E60012]/80 animate-pulse';
                    return (
                      <div
                        key={i}
                        className={`rounded-sm transition-all duration-75 ${
                          isActive ? `${ledColor} shadow-md` : 'bg-white/10'
                        }`}
                      />
                    );
                  })}
                </div>
              </div>

              {/* Interactive SVG Tachometer Dial */}
              <div className="relative flex flex-col items-center justify-center my-4 py-2">
                <svg
                  viewBox="0 0 240 160"
                  className="w-full max-w-[260px] overflow-visible select-none"
                >
                  {/* Gauge Arc Track */}
                  <path
                    d="M 30 135 A 95 95 0 1 1 210 135"
                    fill="none"
                    stroke="rgba(255,255,255,0.08)"
                    strokeWidth="14"
                    strokeLinecap="round"
                  />
                  {/* Redline zone on arc */}
                  <path
                    d="M 183 62 A 95 95 0 0 1 210 135"
                    fill="none"
                    stroke="#E60012"
                    strokeWidth="14"
                    strokeLinecap="round"
                    opacity="0.8"
                  />
                  {/* Dynamic RPM Arc Progress */}
                  <path
                    d="M 30 135 A 95 95 0 1 1 210 135"
                    fill="none"
                    stroke={rpm > 8200 ? '#E60012' : rpm > 6000 ? '#F59E0B' : '#E60012'}
                    strokeWidth="10"
                    strokeLinecap="round"
                    strokeDasharray="440"
                    strokeDashoffset={440 - (rpm / 9500) * 440}
                    className="transition-all duration-75"
                  />

                  {/* RPM Numbers 0 to 9 */}
                  {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => {
                    const angleDeg = -125 + (num / 9.5) * 250;
                    const rad = (angleDeg - 90) * (Math.PI / 180);
                    const x = 120 + Math.cos(rad) * 72;
                    const y = 110 + Math.sin(rad) * 72;
                    return (
                      <text
                        key={num}
                        x={x}
                        y={y}
                        textAnchor="middle"
                        dominantBaseline="middle"
                        fill={num >= 8 ? '#E60012' : '#9CA3AF'}
                        fontSize="11"
                        fontWeight="700"
                        fontFamily="JetBrains Mono"
                      >
                        {num}
                      </text>
                    );
                  })}

                  {/* Needle */}
                  <g
                    transform={`translate(120, 110) rotate(${needleAngle})`}
                    className="transition-transform duration-75 ease-out"
                  >
                    <polygon points="-3,0 0,-78 3,0" fill="#E60012" />
                    <circle cx="0" cy="0" r="8" fill="#1F2430" stroke="#E60012" strokeWidth="2.5" />
                  </g>
                </svg>

                {/* Central Digital Telemetry Readout */}
                <div className="text-center -mt-6">
                  <div className="font-telemetry text-4xl sm:text-5xl font-extrabold text-white tracking-tight flex items-baseline justify-center gap-1">
                    <span>{rpm.toLocaleString()}</span>
                    <span className="text-xs text-amber-400 font-semibold">RPM</span>
                  </div>
                  <div className="flex items-center justify-center gap-2 mt-1">
                    <div className="flex items-center gap-1 bg-[#090A0D] border border-white/10 px-2 py-0.5 rounded-lg text-xs font-telemetry">
                      <span className="text-gray-400">GEAR:</span>
                      {(['2', '3', '4', '5', '6'] as const).map((g) => (
                        <button
                          key={g}
                          onClick={() => setGear(g)}
                          className={`px-1.5 py-0.5 rounded text-[11px] font-bold transition-all ${
                            gear === g
                              ? 'bg-[#E60012] text-white'
                              : 'text-gray-400 hover:text-white'
                          }`}
                        >
                          {g}
                        </button>
                      ))}
                    </div>
                    <span className="text-xs text-amber-400 font-telemetry font-bold bg-amber-500/10 px-2 py-0.5 rounded-lg border border-amber-500/25">
                      OIL: {calcOilTemp}°C
                    </span>
                  </div>
                </div>
              </div>

              {/* Interactive Throttle Pedal Slider */}
              <div className="mt-4 p-4 rounded-xl bg-[#090A0D]/90 border border-white/10">
                <div className="flex items-center justify-between text-xs text-gray-300 font-telemetry mb-2">
                  <span className="flex items-center gap-1.5 text-amber-400 font-bold">
                    <Zap className="h-4 w-4" />
                    اسحب دواسة الوقود للتجربة الحية:
                  </span>
                  <span>
                    THROTTLE: <strong className="text-white">{Math.round(((rpm - 800) / 8200) * 100)}%</strong>
                  </span>
                </div>
                <input
                  type="range"
                  min={800}
                  max={9200}
                  step={50}
                  value={rpm}
                  onChange={(e) => handleThrottleChange(Number(e.target.value))}
                  onMouseUp={() => {
                    if (!isRevving) engineSound.stopRev();
                  }}
                  onTouchEnd={() => {
                    if (!isRevving) engineSound.stopRev();
                  }}
                  className="w-full h-3 bg-[#1F2430] rounded-lg appearance-none cursor-pointer accent-[#E60012] focus:outline-none"
                  aria-label="محاكي دواسة الوقود"
                />
                <div className="flex justify-between text-[10px] font-telemetry text-gray-500 mt-1">
                  <span>800 IDLE</span>
                  <span>4,500 PEAK TORQUE</span>
                  <span className="text-[#E60012]">9,000 REDLINE</span>
                </div>
              </div>

              {/* Live Dyno KPI Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-4">
                <div className="p-2.5 rounded-xl bg-white/[0.03] border border-white/8 text-center">
                  <div className="text-[10px] text-gray-400 font-telemetry uppercase">القوة الحصانية</div>
                  <div className="text-lg font-bold text-white font-telemetry mt-0.5">
                    {calcHp} <span className="text-xs text-[#E60012]">HP</span>
                  </div>
                </div>
                <div className="p-2.5 rounded-xl bg-white/[0.03] border border-white/8 text-center">
                  <div className="text-[10px] text-gray-400 font-telemetry uppercase">عزم الدوران</div>
                  <div className="text-lg font-bold text-white font-telemetry mt-0.5">
                    {calcTorque} <span className="text-xs text-amber-400">Nm</span>
                  </div>
                </div>
                <div className="p-2.5 rounded-xl bg-white/[0.03] border border-white/8 text-center">
                  <div className="text-[10px] text-gray-400 font-telemetry uppercase">ضغط التوربو</div>
                  <div className="text-lg font-bold text-amber-400 font-telemetry mt-0.5">
                    {calcBoostPsi} <span className="text-xs text-white">PSI</span>
                  </div>
                </div>
                <div className="p-2.5 rounded-xl bg-white/[0.03] border border-white/8 text-center">
                  <div className="text-[10px] text-gray-400 font-telemetry uppercase">خليط الوقود</div>
                  <div className="text-xs font-bold text-emerald-400 font-telemetry mt-1.5">
                    {calcAfr}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
