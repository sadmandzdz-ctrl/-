import React, { useState } from 'react';
import {
  Cpu,
  Layers,
  Gauge,
  Wrench,
  GraduationCap,
  Sparkles,
  ArrowUpLeft,
  CheckCircle2,
  Sliders,
  Terminal,
} from 'lucide-react';

interface BentoFeaturesSectionProps {
  onOpenDiagnostic: (code: string) => void;
}

export const BentoFeaturesSection: React.FC<BentoFeaturesSectionProps> = ({
  onOpenDiagnostic,
}) => {
  // Card 1: Interactive DTC Preview
  const [activeDtcCode, setActiveDtcCode] = useState('P0299');
  const dtcPreviews: Record<
    string,
    { title: string; sensor: string; fix: string; torque: string }
  > = {
    P0299: {
      title: 'نقص ضغط شاحن التوربو (Underboost Condition)',
      sensor: 'MAP / Boost Pressure Sensor (0-4 Bar)',
      fix: 'فحص خرطوم الإنترکولر وصمام الـ Wastegate Actuator',
      torque: 'مرابط خرطوم التوربو: 6.5 Nm',
    },
    P0300: {
      title: 'إشعال مفقود عشوائي في الأسطوانات (Random Misfire)',
      sensor: 'Crankshaft Position & Knock Sensors',
      fix: 'فحص فجوة شمعات الإشعال وكويلات الجهد العالي',
      torque: 'بواجي الإشعال M12: 23 Nm',
    },
    P0171: {
      title: 'خليط الوقود فقير جداً في الضفة 1 (System Too Lean)',
      sensor: 'Wideband O2 Lambda Sensor Bank 1',
      fix: 'اختبار تسريب الفاكيوم وتنظيف سلك MAF بالبخاخ المخصص',
      torque: 'براغي ثلاجة السحب: 11 Nm',
    },
    U0100: {
      title: 'انقطاع الاتصال مع كمبيوتر المحرك (CAN-Bus ECM Lost)',
      sensor: 'High-Speed CAN Transceiver Pin 6 & 14',
      fix: 'فحص تأريض الشاصي G101 ومقاومة خط الـ CAN (60 أوم)',
      torque: 'برغي التأريض M8: 18 Nm',
    },
  };

  // Card 2: Interactive Schematic Layer
  const [activeSchematicLayer, setActiveSchematicLayer] = useState<
    'turbo' | 'block' | 'ecu'
  >('turbo');

  // Card 3: Interactive Dyno WHP Calculator
  const [crankHp, setCrankHp] = useState(650);
  const [drivetrainType, setDrivetrainType] = useState<'RWD' | 'AWD' | 'FWD'>('RWD');
  const lossMultiplier =
    drivetrainType === 'RWD' ? 0.86 : drivetrainType === 'AWD' ? 0.81 : 0.88;
  const wheelHp = Math.round(crankHp * lossMultiplier);

  return (
    <section id="features" className="relative py-24 bg-[#090A0D] overflow-hidden">
      {/* Background carbon spotlight */}
      <div className="pointer-events-none absolute top-1/3 left-1/2 -translate-x-1/2 h-[500px] w-[900px] rounded-full bg-[#E60012]/8 blur-[140px]" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="text-right max-w-3xl mb-14">
          <div className="inline-flex items-center gap-2 rounded-full bg-[#14161D] border border-white/12 px-3.5 py-1 text-xs font-telemetry font-bold text-[#E60012] mb-3">
            <Sparkles className="h-3.5 w-3.5" />
            <span>باقة القدرات التكنولوجية المتطورة (TELEMETRY ECOSYSTEM)</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-heading tracking-tight leading-tight">
            أدوات تشخيص وهندسة ميكانيكية مصممة لـ{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-l from-[#E60012] to-amber-400">
              الدقة المتناهية
            </span>
          </h2>
          <p className="text-gray-400 text-base sm:text-lg mt-3 leading-relaxed">
            وداعاً للتخمين في الورشات التقليدية. كل كود عطل، كل برغي ربط، وكل خريطة محرك مدعومة بالبيانات الأصلية والذكاء الاصطناعي التشخيصي.
          </p>
        </div>

        {/* 12-Column Precision Bento Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* ===================== CARD 1 (Span 7 Col): AI OBD-II DTC SCANNER ===================== */}
          <div className="lg:col-span-7 relative rounded-2xl bg-[#14161D]/90 border border-white/12 p-6 sm:p-8 hover:border-[#E60012]/50 transition-all duration-300 flex flex-col justify-between overflow-hidden group">
            <div className="pointer-events-none absolute -top-16 -left-16 h-48 w-48 rounded-full bg-[#E60012]/15 blur-3xl" />

            <div>
              <div className="flex items-center justify-between mb-5">
                <span className="inline-flex items-center gap-2 rounded-lg bg-[#E60012]/15 px-3 py-1 text-xs font-telemetry font-bold text-[#E60012] border border-[#E60012]/30">
                  <Cpu className="h-3.5 w-3.5" />
                  OBD-II AI DIAGNOSTIC ENGINE
                </span>
                <span className="text-xs font-telemetry text-emerald-400 flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                  LIVE CAN-BUS 500kbps
                </span>
              </div>

              <h3 className="text-2xl font-bold text-white font-heading mb-2">
                تشخيص الأعطال الذكي مع خطوات الإصلاح وعزم الربط
              </h3>
              <p className="text-sm text-gray-400 leading-relaxed mb-5">
                اختر كود العطل أدناه لترى كيف يحلل نظام أبِيكْس المسببات الحقيقية بالترتيب الهندسية، مع قيم الربط الدقيقة:
              </p>

              {/* Interactive DTC Quick Selector Pills */}
              <div className="flex flex-wrap gap-2 mb-5">
                {Object.keys(dtcPreviews).map((code) => (
                  <button
                    key={code}
                    onClick={() => setActiveDtcCode(code)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-telemetry font-bold transition-all ${
                      activeDtcCode === code
                        ? 'bg-[#E60012] text-white shadow-lg shadow-[#E60012]/30 scale-105'
                        : 'bg-white/5 text-gray-300 hover:bg-white/10 border border-white/10'
                    }`}
                  >
                    DTC {code}
                  </button>
                ))}
              </div>

              {/* Active DTC Live Oscilloscope & Report Preview Box */}
              <div className="rounded-xl bg-[#090A0D] border border-white/12 p-4 space-y-3">
                <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-[#E60012] text-white font-telemetry text-xs font-bold">
                      {activeDtcCode}
                    </span>
                    <span className="text-xs sm:text-sm font-bold text-white">
                      {dtcPreviews[activeDtcCode].title}
                    </span>
                  </div>
                  <Terminal className="h-4 w-4 text-amber-400" />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-2.5 rounded-lg bg-white/[0.03] border border-white/8">
                    <span className="text-gray-400 block mb-1">الحساس المسؤول:</span>
                    <span className="font-telemetry font-semibold text-amber-400">
                      {dtcPreviews[activeDtcCode].sensor}
                    </span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-white/[0.03] border border-white/8">
                    <span className="text-gray-400 block mb-1">عزم الربط المطلوب (Torque):</span>
                    <span className="font-telemetry font-bold text-emerald-400">
                      {dtcPreviews[activeDtcCode].torque}
                    </span>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-[#14161D] border border-white/10 flex items-start justify-between gap-3">
                  <div className="text-xs text-gray-300">
                    <strong className="text-white">خطوة الإصلاح الأولى: </strong>
                    {dtcPreviews[activeDtcCode].fix}
                  </div>
                  <button
                    onClick={() => onOpenDiagnostic(activeDtcCode)}
                    className="shrink-0 inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#E60012] hover:bg-[#D00010] text-white text-xs font-bold transition-all"
                  >
                    <span>التقرير الكامل</span>
                    <ArrowUpLeft className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>

            <div className="mt-5 flex items-center justify-between text-xs text-gray-400 border-t border-white/10 pt-4">
              <span>+45,000 كود عطل (Powertrain, Chassis, ABS, Airbag, Body CAN)</span>
              <button
                onClick={() => onOpenDiagnostic('P0299')}
                className="text-[#E60012] hover:text-white font-bold inline-flex items-center gap-1"
              >
                افتح محلل الأكواد الشامل ←
              </button>
            </div>
          </div>

          {/* ===================== CARD 2 (Span 5 Col): 3D EXPLODED SCHEMATICS ===================== */}
          <div className="lg:col-span-5 relative rounded-2xl bg-[#14161D]/90 border border-white/12 p-6 sm:p-8 hover:border-[#E60012]/50 transition-all duration-300 flex flex-col justify-between overflow-hidden">
            <div>
              <div className="flex items-center justify-between mb-5">
                <span className="inline-flex items-center gap-2 rounded-lg bg-amber-500/15 px-3 py-1 text-xs font-telemetry font-bold text-amber-400 border border-amber-500/30">
                  <Layers className="h-3.5 w-3.5" />
                  3D EXPLODED BLUEPRINTS
                </span>
                <span className="text-xs font-telemetry text-gray-400">OEM CAD SCHEMATICS</span>
              </div>

              <h3 className="text-2xl font-bold text-white font-heading mb-2">
                مخططات المحركات والضفائر التفاعلية
              </h3>
              <p className="text-sm text-gray-400 leading-relaxed mb-4">
                تصفح تشريح المحركات وخطوط تزييت التوربو وضفائر الـ ECU بدقة مليمترية:
              </p>

              {/* Interactive Layer Switcher */}
              <div className="grid grid-cols-3 gap-2 mb-4">
                <button
                  onClick={() => setActiveSchematicLayer('turbo')}
                  className={`py-2 px-2.5 rounded-xl text-xs font-bold transition-all ${
                    activeSchematicLayer === 'turbo'
                      ? 'bg-amber-500 text-black shadow-lg'
                      : 'bg-[#090A0D] text-gray-300 border border-white/10'
                  }`}
                >
                  نظام التوربو والسحب
                </button>
                <button
                  onClick={() => setActiveSchematicLayer('block')}
                  className={`py-2 px-2.5 rounded-xl text-xs font-bold transition-all ${
                    activeSchematicLayer === 'block'
                      ? 'bg-amber-500 text-black shadow-lg'
                      : 'bg-[#090A0D] text-gray-300 border border-white/10'
                  }`}
                >
                  البساتين وعمود الكرنك
                </button>
                <button
                  onClick={() => setActiveSchematicLayer('ecu')}
                  className={`py-2 px-2.5 rounded-xl text-xs font-bold transition-all ${
                    activeSchematicLayer === 'ecu'
                      ? 'bg-amber-500 text-black shadow-lg'
                      : 'bg-[#090A0D] text-gray-300 border border-white/10'
                  }`}
                >
                  ضفيرة ECU ومخارج Pinout
                </button>
              </div>

              {/* Technical Schematic Graphic Card */}
              <div className="relative rounded-xl bg-[#090A0D] border border-white/12 p-4 overflow-hidden">
                {/* CAD Grid Lines */}
                <div className="absolute inset-0 bg-carbon-brushed opacity-60" />
                <div className="relative z-10 space-y-2">
                  <div className="flex items-center justify-between text-xs font-telemetry">
                    <span className="text-amber-400 font-bold">
                      {activeSchematicLayer === 'turbo'
                        ? 'TWIN-TURBO OIL & COOLANT FEED'
                        : activeSchematicLayer === 'block'
                        ? 'FORGED PISTON & TITANIUM ROD SPEC'
                        : 'BOSCH MOTRONIC MG1 PINOUT HARNESS'}
                    </span>
                    <span className="text-emerald-400">REV. 2026</span>
                  </div>

                  <div className="p-3 rounded-lg bg-[#14161D]/80 border border-white/10 text-xs text-gray-300 space-y-1.5">
                    {activeSchematicLayer === 'turbo' && (
                      <>
                        <div className="flex justify-between">
                          <span>خط تغذية زيت التوربو (Oil Feed):</span>
                          <span className="font-telemetry text-white font-bold">AN-4 Braided Steel (45 PSI)</span>
                        </div>
                        <div className="flex justify-between">
                          <span>صمام الـ Wastegate Spring:</span>
                          <span className="font-telemetry text-amber-400 font-bold">14.5 PSI Base Boost</span>
                        </div>
                      </>
                    )}
                    {activeSchematicLayer === 'block' && (
                      <>
                        <div className="flex justify-between">
                          <span>خلوص حلقات البستم (Ring Gap Top):</span>
                          <span className="font-telemetry text-white font-bold">0.018&quot; - 0.020&quot; Boosted</span>
                        </div>
                        <div className="flex justify-between">
                          <span>عزم براغي أذرع التوصيل (ARP 2000):</span>
                          <span className="font-telemetry text-amber-400 font-bold">75 ft-lbs + شحم ARP</span>
                        </div>
                      </>
                    )}
                    {activeSchematicLayer === 'ecu' && (
                      <>
                        <div className="flex justify-between">
                          <span>تغذية حساس الكرنك 5V Reference:</span>
                          <span className="font-telemetry text-white font-bold">Pin B34 (سلك أزرق/أبيض)</span>
                        </div>
                        <div className="flex justify-between">
                          <span>مخرج كويل الإشعال أسطوانة #1:</span>
                          <span className="font-telemetry text-amber-400 font-bold">Pin A12 (IGT1 Signal)</span>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <a
              href="#showcase"
              className="mt-5 inline-flex items-center justify-between w-full px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-bold text-gray-200 transition-colors"
            >
              <span>افتح مستكشف المحرك التفاعلي 3D</span>
              <ArrowUpLeft className="h-4 w-4 text-[#E60012]" />
            </a>
          </div>

          {/* ===================== CARD 3 (Span 4 Col): LIVE DYNO WHP LOSS CALCULATOR ===================== */}
          <div className="lg:col-span-4 rounded-2xl bg-[#14161D]/90 border border-white/12 p-6 hover:border-[#E60012]/50 transition-all duration-300 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-500/15 px-2.5 py-1 text-xs font-telemetry font-bold text-emerald-400 border border-emerald-500/30">
                  <Gauge className="h-3.5 w-3.5" />
                  DYNO WHP SIMULATOR
                </span>
                <Sliders className="h-4 w-4 text-gray-400" />
              </div>
              <h3 className="text-xl font-bold text-white font-heading mb-2">
                حاسبة قوة العجلات على الداينو (WHP)
              </h3>
              <p className="text-xs text-gray-400 leading-relaxed mb-4">
                احسب فقدان مجموعة نقل الحركة الفعلي من الكرنك إلى الكفرات:
              </p>

              {/* Drivetrain Selector */}
              <div className="grid grid-cols-3 gap-1.5 mb-4">
                {(['RWD', 'AWD', 'FWD'] as const).map((dt) => (
                  <button
                    key={dt}
                    onClick={() => setDrivetrainType(dt)}
                    className={`py-1.5 rounded-lg text-xs font-telemetry font-bold transition-all ${
                      drivetrainType === dt
                        ? 'bg-[#E60012] text-white'
                        : 'bg-[#090A0D] text-gray-400 border border-white/10'
                    }`}
                  >
                    {dt} ({dt === 'RWD' ? '-14%' : dt === 'AWD' ? '-19%' : '-12%'})
                  </button>
                ))}
              </div>

              {/* Crank HP Slider */}
              <div className="p-3.5 rounded-xl bg-[#090A0D] border border-white/10 mb-3">
                <div className="flex justify-between text-xs font-telemetry mb-1.5">
                  <span className="text-gray-400">قوة المحرك (Crank HP):</span>
                  <span className="text-white font-bold">{crankHp} HP</span>
                </div>
                <input
                  type="range"
                  min={250}
                  max={1400}
                  step={25}
                  value={crankHp}
                  onChange={(e) => setCrankHp(Number(e.target.value))}
                  className="w-full h-2 bg-[#1F2430] rounded-lg appearance-none cursor-pointer accent-[#E60012]"
                  aria-label="قوة المحرك بالحصان"
                />
              </div>

              {/* Result WHP Display */}
              <div className="p-3.5 rounded-xl bg-gradient-to-l from-[#E60012]/15 to-transparent border border-[#E60012]/30 flex items-center justify-between">
                <div>
                  <div className="text-[11px] text-gray-400 font-telemetry">قوة العجلات الصافية (WHP)</div>
                  <div className="text-2xl font-extrabold text-white font-telemetry">
                    {wheelHp} <span className="text-xs text-[#E60012]">WHP</span>
                  </div>
                </div>
                <div className="text-left text-xs font-telemetry text-amber-400">
                  فقدان: {crankHp - wheelHp} HP
                </div>
              </div>
            </div>
            <div className="mt-4 text-[11px] text-gray-500 font-telemetry">
              معتمد على جداول حاسبات Mustang Dyno و Dynojet الخليجية
            </div>
          </div>

          {/* ===================== CARD 4 (Span 4 Col): TORQUE SPEC FAST DATABASE ===================== */}
          <div className="lg:col-span-4 rounded-2xl bg-[#14161D]/90 border border-white/12 p-6 hover:border-[#E60012]/50 transition-all duration-300 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="inline-flex items-center gap-1.5 rounded-lg bg-amber-500/15 px-2.5 py-1 text-xs font-telemetry font-bold text-amber-400 border border-amber-500/30">
                  <Wrench className="h-3.5 w-3.5" />
                  TORQUE SPECS INDEX
                </span>
                <span className="text-xs font-telemetry text-gray-400">ISO 6789</span>
              </div>
              <h3 className="text-xl font-bold text-white font-heading mb-2">
                دليل عزم الربط القياسي (Nm / Ft-Lbs)
              </h3>
              <p className="text-xs text-gray-400 leading-relaxed mb-4">
                قيم ربط البراغي للمحركات الشهيرة لتفادي انقطاع المسامير أو تسريب الجاسكيت:
              </p>

              <div className="space-y-2">
                {[
                  {
                    engine: '2JZ-GTE / 1FZ-FE',
                    part: 'رأس السلندر (Head Studs)',
                    spec: '39 Nm + 90° + 90°',
                  },
                  {
                    engine: 'LS3 / LS7 6.2L V8',
                    part: 'بكرات الكرنك (Harmonic Balancer)',
                    spec: '330 Nm (مع لوكتايت أزرق)',
                  },
                  {
                    engine: 'Porsche 9A2 / GT3',
                    part: 'السنتر لوك (Center Lock Wheel)',
                    spec: '600 Nm ± 10 عزم ديناميكي',
                  },
                  {
                    engine: 'Nissan VR38DETT',
                    part: 'براغي كراسي الكرنك (Main Caps)',
                    spec: '35 Nm + زاوية 60°',
                  },
                ].map((row, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-xl bg-[#090A0D] border border-white/10 flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-telemetry font-bold text-white block">
                        {row.engine}
                      </span>
                      <span className="text-gray-400 text-[11px]">{row.part}</span>
                    </div>
                    <span className="font-telemetry font-bold text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/25">
                      {row.spec}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-4 flex items-center justify-between text-xs text-gray-400">
              <span>تغطية كاملة للمحركات اليابانية والألمانية والأمريكية</span>
              <CheckCircle2 className="h-4 w-4 text-emerald-400" />
            </div>
          </div>

          {/* ===================== CARD 5 (Span 4 Col): PRO ACADEMY & MASTER COMMUNITY ===================== */}
          <div className="lg:col-span-4 rounded-2xl bg-[#14161D]/90 border border-white/12 p-6 hover:border-[#E60012]/50 transition-all duration-300 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="inline-flex items-center gap-1.5 rounded-lg bg-[#E60012]/15 px-2.5 py-1 text-xs font-telemetry font-bold text-[#E60012] border border-[#E60012]/30">
                  <GraduationCap className="h-3.5 w-3.5" />
                  APEX ENGINEERING ACADEMY
                </span>
                <span className="text-xs text-emerald-400 font-bold">بث مباشر أسبوعي</span>
              </div>
              <h3 className="text-xl font-bold text-white font-heading mb-2">
                أكاديمية الاحتراف ومجتمع المهندسين
              </h3>
              <p className="text-xs text-gray-400 leading-relaxed mb-4">
                دورات تخصصية في برمجة الـ Standalone ECU (MoTeC / Syvecs / Haltech)، قراءة الأوسيلوسكوب، وتوضيب المحركات الرياضية.
              </p>

              <div className="space-y-2.5">
                <div className="p-3 rounded-xl bg-[#090A0D] border border-white/10">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-bold text-white">دورة قراءة وتعديل خرائط الوقود والإشعال</span>
                    <span className="font-telemetry text-emerald-400">12 ساعة فيديو HD</span>
                  </div>
                  <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-[#E60012] h-full w-4/5 rounded-full" />
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-[#090A0D] border border-white/10">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-bold text-white">تشخيص أعطال شبكات CAN-Bus وFlexRay</span>
                    <span className="font-telemetry text-amber-400">شهادة معتمدة</span>
                  </div>
                  <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-amber-400 h-full w-full rounded-full" />
                  </div>
                </div>
              </div>
            </div>

            <a
              href="#pricing"
              className="mt-4 inline-flex items-center justify-center gap-2 w-full py-2.5 rounded-xl bg-[#E60012]/15 hover:bg-[#E60012] text-[#E60012] hover:text-white border border-[#E60012]/40 text-xs font-bold transition-all"
            >
              <span>انضم لنخبة مجتمع أبِيكْس ميكانيكا</span>
              <ArrowUpLeft className="h-3.5 w-3.5" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
