import React from 'react';
import { Sparkles, ChevronLeft, Cpu, ShieldCheck, Zap } from 'lucide-react';

interface FinalCtaSectionProps {
  onOpenSignup: () => void;
  onOpenDiagnostic: () => void;
}

export const FinalCtaSection: React.FC<FinalCtaSectionProps> = ({
  onOpenSignup,
  onOpenDiagnostic,
}) => {
  return (
    <section className="relative py-24 bg-[#090A0D] overflow-hidden">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl bg-gradient-to-r from-[#14161D] via-[#1A1D29] to-[#14161D] border border-white/15 p-8 sm:p-14 overflow-hidden shadow-2xl glow-crimson">
          {/* Background telemetry rings */}
          <div className="pointer-events-none absolute -right-20 -top-20 h-80 w-80 rounded-full border border-white/10 opacity-30" />
          <div className="pointer-events-none absolute -left-20 -bottom-20 h-96 w-96 rounded-full bg-[#E60012]/15 blur-3xl" />

          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-8 text-right space-y-5">
              <div className="inline-flex items-center gap-2 rounded-full bg-[#E60012]/15 border border-[#E60012]/40 px-4 py-1.5 text-xs font-telemetry font-bold text-amber-400">
                <Zap className="h-4 w-4 text-[#E60012]" />
                <span>جاهز للارتقاء بمهاراتك أو ورشتك إلى الخط الأحمر (REDLINE)؟</span>
              </div>

              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-heading leading-tight">
                انضم الآن إلى أكثر من{' '}
                <span className="text-[#E60012]">18,500 مهندس وميكانيكي وهاوي</span>{' '}
                يصنعون الفارق يومياً
              </h2>

              <p className="text-base sm:text-lg text-gray-300 max-w-2xl leading-relaxed">
                لا تترك سيارتك أو عملاء ورشتك ضحية للتخمين بعد اليوم. جرب المنصة الاحترافية الأولى في عالم المحركات وميكانيك السيارات مجاناً لمدة 14 يوماً.
              </p>

              <div className="flex flex-wrap items-center gap-6 text-xs sm:text-sm text-gray-300 pt-2">
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="h-4 w-4 text-emerald-400" />
                  بدون بطاقة ائتمان للتجربة
                </span>
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="h-4 w-4 text-emerald-400" />
                  دعم فني هندسي مباشر
                </span>
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="h-4 w-4 text-emerald-400" />
                  إلغاء فوري بضغطة زر
                </span>
              </div>
            </div>

            <div className="lg:col-span-4 flex flex-col gap-3.5">
              <button
                onClick={onOpenSignup}
                className="w-full inline-flex items-center justify-center gap-2.5 px-7 py-4 rounded-xl bg-[#E60012] hover:bg-[#D00010] text-white text-base font-bold transition-all shadow-xl shadow-[#E60012]/40 active:scale-[0.98]"
              >
                <Sparkles className="h-5 w-5" />
                <span>ابدأ التجربة المجانية 14 يوماً</span>
                <ChevronLeft className="h-5 w-5" />
              </button>

              <button
                onClick={onOpenDiagnostic}
                className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-[#090A0D]/90 hover:bg-white/10 text-gray-200 border border-white/15 text-sm font-bold transition-all"
              >
                <Cpu className="h-4 w-4 text-amber-400" />
                <span>جرّب تشخيص كود عطل OBD-II الآن</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
