import React from 'react';
import { ShieldCheck, Award, Wrench } from 'lucide-react';

export const SocialProofSection: React.FC = () => {
  const partners = [
    {
      code: 'PORSCHE 911 GT3 RS',
      name: 'PIWIS III & CAN Telemetry',
      badge: 'STUTTGART LAB',
    },
    {
      code: 'BMW M-POWER S58/S63',
      name: 'ISTA+ Protocols Verified',
      badge: 'MUNICH M-TECH',
    },
    {
      code: 'TOYOTA GAZOO RACING',
      name: '2JZ / 1FZ / B58 Schematics',
      badge: 'GULF DESERT TUNING',
    },
    {
      code: 'NISSAN GT-R NISMO',
      name: 'VR38DETT Dual-ECU Tuning',
      badge: 'ATTESA E-TS PRO',
    },
    {
      code: 'MERCEDES-AMG ONE',
      name: 'F1 Hybrid Powertrain DTC',
      badge: 'AFFALTERBACH',
    },
    {
      code: 'AMERICAN MUSCLE LS/HEMI',
      name: 'Hellcat Supercharged Maps',
      badge: 'NHRA DRAG SPEC',
    },
  ];

  return (
    <section className="relative py-14 bg-[#090A0D] border-y border-white/10 overflow-hidden">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-8">
          <div className="flex items-center gap-3">
            <span className="flex h-3 w-3 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs sm:text-sm font-telemetry font-semibold text-gray-300">
              معتمد ومستخدم يومياً في +680 مركز صيانة وفريق سباقات وهاوي تعديل في الرياض ودبي وأبوظبي وعمّان والكويت
            </span>
          </div>

          <div className="flex items-center gap-4 text-xs font-telemetry text-gray-400">
            <span className="flex items-center gap-1.5 text-amber-400">
              <Award className="h-4 w-4" />
              ISO 15031 / SAE J1979
            </span>
            <span className="h-3 w-px bg-white/20" />
            <span className="flex items-center gap-1.5 text-emerald-400">
              <ShieldCheck className="h-4 w-4" />
              تحديثات يومية للأكواد
            </span>
          </div>
        </div>

        {/* Metallic Precision OEM Protocol Cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
          {partners.map((partner, idx) => (
            <div
              key={idx}
              className="group relative rounded-xl bg-[#14161D]/70 border border-white/10 p-3.5 hover:border-[#E60012]/60 hover:bg-[#14161D] transition-all duration-300 text-right"
            >
              <div className="flex items-center justify-between text-[10px] font-telemetry text-gray-500 mb-2">
                <span className="text-amber-400/90 font-bold">{partner.badge}</span>
                <Wrench className="h-3.5 w-3.5 text-gray-500 group-hover:text-[#E60012] transition-colors" />
              </div>
              <div className="font-heading font-bold text-xs sm:text-sm text-white group-hover:text-[#E60012] transition-colors">
                {partner.code}
              </div>
              <div className="text-[11px] font-telemetry text-gray-400 mt-0.5">
                {partner.name}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
