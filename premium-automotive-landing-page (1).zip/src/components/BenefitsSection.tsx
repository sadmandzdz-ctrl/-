import React, { useState } from 'react';
import {
  Flame,
  Wrench,
  CheckCircle2,
  TrendingUp,
  Clock,
  ShieldCheck,
  Zap,
  Award,
} from 'lucide-react';

export const BenefitsSection: React.FC = () => {
  const [activePersona, setActivePersona] = useState<'enthusiast' | 'pro'>('pro');

  const enthusiastBenefits = [
    {
      title: 'افهم سيارتك كمهندس سباقات وليس مجرد سائق',
      desc: 'تعلم قراءة أكواد المحرك ومخططات الأداء بنفسك دون أن تتعرض للاستغلال أو التشخيص الخاطئ في الورش التجارية.',
      icon: Flame,
      stat: '100% ثقة في قرارات التعديل',
    },
    {
      title: 'محاكاة التعديل قبل صرف آلاف الريالات',
      desc: 'جرب إضافة الداون بايب، الإنترکولر، أو التوربو الأكبر على الداينو الافتراضي لتعرف الزيادة الحقيقية بالحصان وعزم الدوران.',
      icon: TrendingUp,
      stat: '+85 حصان تقدير دقيق',
    },
    {
      title: 'مجتمع شغوف من ملاك سيارات الأداء الفائق',
      desc: 'ناقش أسرار محركات 2JZ و LS و VR38 و S58 مع مهندسين أبطال حلبات في الرياض ودبي والكويت.',
      icon: Award,
      stat: '+18,500 عضو نشط',
    },
  ];

  const proBenefits = [
    {
      title: 'اختصر وقت تشخيص العطل المعقد بنسبة 74%',
      desc: 'بدلاً من تبديل القطع بالتجربة، يمنحك الذكاء الاصطناعي شجرة فحص دقيقة مدعومة بقيم الفولتية ومقاومة الأسلاك من فيشة ECU.',
      icon: Zap,
      stat: 'توفير 3.5 ساعات يومياً',
    },
    {
      title: 'جداول عزم ربط OEM أصلية تمنع رجوع العميل',
      desc: 'تجنب قطع مسامير رأس السلندر أو تلف الجاسكيت بفضل دليل التورك المعتمد بالنيوتن متر وزاوية الدوران المطابق لكتيبات الوكالة.',
      icon: ShieldCheck,
      stat: '0% أخطاء ربط في الورشة',
    },
    {
      title: 'ارفع أرباح ورشتك وسمعتك الفنية فوراً',
      desc: 'اطبع لعميلك تقرير تشخيص هندسي احترافي بشعار مركزك، ومخطط العطل قبل وبعد الإصلاح لتعزيز الثقة.',
      icon: Clock,
      stat: '+42% زيادة في رضا العملاء',
    },
  ];

  const currentBenefits = activePersona === 'enthusiast' ? enthusiastBenefits : proBenefits;

  return (
    <section id="benefits" className="relative py-24 bg-[#090A0D] overflow-hidden">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header & Persona Switcher */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="inline-flex items-center gap-2 rounded-full bg-[#14161D] border border-white/12 px-4 py-1 text-xs font-telemetry font-bold text-[#E60012] mb-3">
            TAILORED FOR ENTHUSIASTS & PROS
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-heading tracking-tight">
            سواء كنت{' '}
            <span className="text-[#E60012]">عاشقاً لتعديل سيارتك</span>{' '}
            أو{' '}
            <span className="text-amber-400">مهندساً محترفاً</span>
          </h2>
          <p className="text-gray-400 text-base sm:text-lg mt-3">
            اختر ملفك الشخصي أدناه لترى كيف تضاعف منصة أبِيكْس ميكانيكا شغفك وأداءك:
          </p>

          {/* Interactive Toggle Pill */}
          <div className="mt-8 inline-flex p-1.5 rounded-2xl bg-[#14161D] border border-white/15 shadow-xl">
            <button
              onClick={() => setActivePersona('pro')}
              className={`flex items-center gap-2.5 px-6 py-3 rounded-xl text-sm font-bold transition-all ${
                activePersona === 'pro'
                  ? 'bg-gradient-to-l from-amber-500 to-amber-600 text-black shadow-lg shadow-amber-500/25 scale-[1.02]'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Wrench className="h-4 w-4" />
              <span>للميكانيكيين ومراكز الصيانة الاحترافية</span>
            </button>

            <button
              onClick={() => setActivePersona('enthusiast')}
              className={`flex items-center gap-2.5 px-6 py-3 rounded-xl text-sm font-bold transition-all ${
                activePersona === 'enthusiast'
                  ? 'bg-[#E60012] text-white shadow-lg shadow-[#E60012]/30 scale-[1.02]'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Flame className="h-4 w-4" />
              <span>لعشاق السيارات والأداء الفائق</span>
            </button>
          </div>
        </div>

        {/* 3-Column Dynamic Benefit Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {currentBenefits.map((item, idx) => {
            const IconComp = item.icon;
            return (
              <div
                key={idx}
                className="relative rounded-2xl bg-[#14161D]/90 border border-white/12 p-7 hover:border-[#E60012]/60 transition-all duration-300 flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between mb-5">
                    <div
                      className={`flex h-12 w-12 items-center justify-center rounded-xl ${
                        activePersona === 'pro'
                          ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                          : 'bg-[#E60012]/15 text-[#E60012] border border-[#E60012]/30'
                      }`}
                    >
                      <IconComp className="h-6 w-6" />
                    </div>
                    <span className="px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-telemetry font-bold text-white">
                      {item.stat}
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-white font-heading mb-3 leading-snug group-hover:text-[#E60012] transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-sm text-gray-400 leading-relaxed">
                    {item.desc}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-white/10 flex items-center gap-2 text-xs font-semibold text-emerald-400">
                  <CheckCircle2 className="h-4 w-4" />
                  <span>متوفر في الباقة الفورية والمجانية التجريبية</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Comparison Strip: Conventional Workshop vs Apex Mechanica */}
        <div className="mt-14 rounded-2xl bg-[#14161D] border border-white/12 p-6 sm:p-8">
          <div className="text-center mb-6">
            <h4 className="text-lg sm:text-xl font-bold text-white font-heading">
              مقارنة صريحة: التشخيص التقليدي مقابل أبِيكْس ميكانيكا
            </h4>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs sm:text-sm">
            <div className="p-4 rounded-xl bg-red-950/20 border border-red-500/25 text-right space-y-2">
              <span className="text-red-400 font-bold block mb-1">الورش والبحث العشوائي التقليدي:</span>
              <p className="text-gray-300">❌ تبديل الحساسات بالحدس وصرف أموال على قطع غير تالفة</p>
              <p className="text-gray-300">❌ شد البراغي بدون تورك ميتر مما يسبب شروخ رأس المحرك</p>
              <p className="text-gray-300">❌ غياب مخططات أسلاك ECU للسيارات الحديثة 2020-2026</p>
            </div>

            <div className="md:col-span-2 p-4 rounded-xl bg-gradient-to-l from-[#E60012]/15 via-emerald-950/20 to-transparent border border-[#E60012]/40 text-right space-y-2">
              <span className="text-[#E60012] font-bold block mb-1">
                منصة أبِيكْس ميكانيكا الاحترافية (APEX PRO):
              </span>
              <p className="text-gray-200">
                ✅ تشخيص مباشر لشجرة الأعطال (DTC Pinpoint Test) يحدد الحساس أو السلك التالف بدقة 99.4%
              </p>
              <p className="text-gray-200">
                ✅ دليل عزم ربط المصنع (OEM Torque Specs) وزوايا الشد لجميع المحركات الرياضية والعائلية
              </p>
              <p className="text-gray-200">
                ✅ مخططات كهربائية تفاعلية ملونة 3D لكل فيشة وسلك من الكومبيوتر إلى الحساسات
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
