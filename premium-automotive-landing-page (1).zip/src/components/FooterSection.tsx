import React, { useState } from 'react';
import {
  Gauge,
  Search,
  Activity,
  Terminal,
} from 'lucide-react';

interface FooterSectionProps {
  onOpenDiagnostic: (code?: string) => void;
}

export const FooterSection: React.FC<FooterSectionProps> = ({ onOpenDiagnostic }) => {
  const [quickCodeInput, setQuickCodeInput] = useState('');

  const handleQuickLookup = (e: React.FormEvent) => {
    e.preventDefault();
    if (quickCodeInput.trim()) {
      onOpenDiagnostic(quickCodeInput.trim().toUpperCase());
      setQuickCodeInput('');
    }
  };

  return (
    <footer className="relative bg-[#090A0D] border-t border-white/12 text-right pt-16 pb-12 overflow-hidden">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Top Telemetry Server Status & Quick DTC Search Bar */}
        <div className="rounded-2xl bg-[#14161D] border border-white/12 p-6 mb-12 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400">
              <Activity className="h-5 w-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
                <span className="text-xs font-telemetry font-bold text-emerald-400">
                  ALL APEX TELEMETRY & OEM BLUEPRINT SERVERS ONLINE
                </span>
              </div>
              <p className="text-xs text-gray-400 mt-0.5">
                تحديث فوري لقواعد بيانات أكواد الأعطال وجداول عزم الربط لعام 2026
              </p>
            </div>
          </div>

          {/* Quick DTC Footer Lookup */}
          <form
            onSubmit={handleQuickLookup}
            className="flex items-center gap-2 w-full md:w-auto"
          >
            <div className="relative flex-1 md:w-64">
              <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
              <input
                type="text"
                value={quickCodeInput}
                onChange={(e) => setQuickCodeInput(e.target.value)}
                placeholder="ابحث بكود عطل سريع (P0299)..."
                className="w-full rounded-xl bg-[#090A0D] border border-white/15 pr-9 pl-3 py-2.5 text-xs text-white font-telemetry placeholder-gray-500 focus:outline-none focus:border-[#E60012]"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2.5 rounded-xl bg-[#E60012] hover:bg-[#D00010] text-white text-xs font-bold font-telemetry transition-colors"
            >
              فحص فوري
            </button>
          </form>
        </div>

        {/* 5-Column Navigation Matrix */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 pb-12 border-b border-white/10">
          {/* Brand Col */}
          <div className="col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-[#E60012] to-[#8C000B] text-white">
                <Gauge className="h-5 w-5" />
              </div>
              <div>
                <span className="font-heading text-lg font-extrabold text-white block">
                  أبِيكْس ميكانيكا | APEX MECHANICA
                </span>
                <span className="text-[11px] text-gray-400 font-telemetry">
                  PRECISION AUTOMOTIVE ENGINEERING
                </span>
              </div>
            </div>
            <p className="text-xs sm:text-sm text-gray-400 leading-relaxed max-w-sm">
              المنصة العربية الأولى المتخصصة في تشخيص أعطال السيارات بالذكاء الاصطناعي، ومخططات المحركات ثلاثية الأبعاد، وجداول عزم الربط القياسية لعشاق المحركات والمحترفين.
            </p>
            <div className="flex items-center gap-2 text-xs font-telemetry text-amber-400">
              <Terminal className="h-4 w-4" />
              <span>SUPPORT: RIYADH • DUBAI • AMMAN • KUWAIT</span>
            </div>
          </div>

          {/* Col 2 */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white font-heading">أدوات التشخيص</h4>
            <ul className="space-y-2 text-xs text-gray-400">
              <li>
                <button
                  onClick={() => onOpenDiagnostic('P0299')}
                  className="hover:text-[#E60012] transition-colors"
                >
                  كاشف أكواد OBD-II بالذكاء الاصطناعي
                </button>
              </li>
              <li>
                <a href="#showcase" className="hover:text-white transition-colors">
                  مستكشف تشريح المحرك 3D
                </a>
              </li>
              <li>
                <a href="#features" className="hover:text-white transition-colors">
                  حاسبة قوة العجلات على الداينو WHP
                </a>
              </li>
              <li>
                <a href="#features" className="hover:text-white transition-colors">
                  دليل عزم الربط القياسي (Nm / Ft-Lbs)
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3 */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white font-heading">أشهر المحركات</h4>
            <ul className="space-y-2 text-xs font-telemetry text-gray-400">
              <li>
                <button
                  onClick={() => onOpenDiagnostic('P0300')}
                  className="hover:text-amber-400 transition-colors"
                >
                  Nissan VR38DETT (GT-R R35)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenDiagnostic('P0171')}
                  className="hover:text-amber-400 transition-colors"
                >
                  Toyota 2JZ-GTE / 1FZ-FE
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenDiagnostic('P0011')}
                  className="hover:text-amber-400 transition-colors"
                >
                  Porsche 9A2 / Mezger Flat-6
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenDiagnostic('U0100')}
                  className="hover:text-amber-400 transition-colors"
                >
                  BMW S58 / S63 TwinTurbo
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4 */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white font-heading">المنصة والورش</h4>
            <ul className="space-y-2 text-xs text-gray-400">
              <li>
                <a href="#benefits" className="hover:text-white transition-colors">
                  مقارنة الهاوي والميكانيكي المحترف
                </a>
              </li>
              <li>
                <a href="#pricing" className="hover:text-white transition-colors">
                  حاسبة العائد الاستثماري للورش (ROI)
                </a>
              </li>
              <li>
                <a href="#testimonials" className="hover:text-white transition-colors">
                  شهادات أبطال الحلبات والمهندسين
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-white transition-colors">
                  الأسئلة الشائعة والدعم الفني
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Copyright & Compliance */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-500 font-telemetry">
          <div>
            © {new Date().getFullYear()} أبِيكْس ميكانيكا (APEX MECHANICA). جميع الحقوق محفوظة لعشاق ومحترفي عالم السيارات.
          </div>
          <div className="flex items-center gap-6">
            <span className="hover:text-gray-300 cursor-pointer">شروط الاستخدام الهندسية</span>
            <span className="hover:text-gray-300 cursor-pointer">سياسة الخصوصية وحماية بيانات OBD-II</span>
            <span className="text-amber-400/90 font-bold">ISO 15031-6 COMPLIANT</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
