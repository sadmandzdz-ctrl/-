import React, { useState } from 'react';
import {
  Layers,
  Cpu,
  Activity,
  Maximize2,
  CheckCircle2,
} from 'lucide-react';

interface HotspotData {
  id: number;
  xPos: number; // percentage left
  yPos: number; // percentage top
  title: string;
  engTitle: string;
  specCode: string;
  description: string;
  material: string;
  maxStress: string;
  torqueOrBoost: string;
}

const ENGINE_HOTSPOTS: HotspotData[] = [
  {
    id: 1,
    xPos: 32,
    yPos: 28,
    title: 'شواحن التوربو المزدوجة التيتانيوم (Twin-Scroll BorgWarner EFR)',
    engTitle: 'Gamma-TiAl Turbine Wheels with Ceramic Ball Bearings',
    specCode: 'TURBO-EFR-8374-TS',
    description:
      'شفرات توربين مصنوعة من سبيكة تيتانيوم ألومينيد بوزن أخف 50% من الإنكونيل التقليدي، مع استجابة بوست فورية من 2,400 دورة.',
    material: 'Gamma Titanium Aluminide (γ-TiAl)',
    maxStress: '1050°C درجة حرارة غاز العادم (EGT)',
    torqueOrBoost: 'ضغط معزز يصل إلى 34.0 PSI (2.35 Bar)',
  },
  {
    id: 2,
    xPos: 54,
    yPos: 46,
    title: 'بساتين الألمنيوم المطروق 2618 وأذرع التيتانيوم',
    engTitle: 'CNC Forged 2618-T61 Pistons & H-Beam Titanium Rods',
    specCode: 'PISTON-FORGE-92MM',
    description:
      'تصميم تاج البستم مضاد للتصفيق (Anti-Detonation Bowl) مطلي بسيراميك حراري لحماية سطح الاحتراق حتى ضغط أسطوانة 240 بار.',
    material: 'Billet 2618-T61 Aluminum + DLC Coated Pins',
    maxStress: 'تحمل ضغط احتراق أقصى 1,650 حصان',
    torqueOrBoost: 'عزم ربط مسامير الأذرع: 102 Nm مع شحم ARP',
  },
  {
    id: 3,
    xPos: 72,
    yPos: 34,
    title: 'مجمع سحب CNC ثنائي الحاقنات (Dual-Injector Intake)',
    engTitle: 'Carbon/Billet Intake Manifold with 16 Injectors',
    specCode: 'INTAKE-DUAL-RAIL-E85',
    description:
      'نظام حقن مزدوج (Direct Injection + Port Injection) يضمن تبريد الهواء الداخل بالوقود الإيثانول E85 ويمنع تراكم الكربون على الصمامات.',
    material: 'Pre-preg Carbon Fiber + 6061-T6 Billet Runners',
    maxStress: 'تدفق هواء 1,250 CFM بدون هبوط ضغط',
    torqueOrBoost: 'ضغط مسطرة الوقود: 2,900 PSI (GDI)',
  },
  {
    id: 4,
    xPos: 48,
    yPos: 76,
    title: 'نظام التزييت بالحوض الجاف 6 مراحل (Dry Sump Scavenge)',
    engTitle: 'CNC Billet 6-Stage Dry Sump Oil Pump System',
    specCode: 'LUBE-DRYSUMP-6STG',
    description:
      'مضخة شفط زيت سداسية المراحل تمنع تجويف الزيت (Oil Starvation) أثناء المنعطفات الجانبية العنيفة 2.5G على حلبة السباق.',
    material: 'Anodized Billet 7075-T6 Housing',
    maxStress: 'ضغط زيت ثابت 75 PSI عند 9,000 RPM',
    torqueOrBoost: 'سعة الخزان الخارجي: 11.5 لتر تخليقي 10W-60',
  },
];

export const ProductShowcaseSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'cutaway' | 've-table'>('cutaway');
  const [selectedHotspot, setSelectedHotspot] = useState<HotspotData>(ENGINE_HOTSPOTS[0]);
  const [selectedVeCell, setSelectedVeCell] = useState<{ rpm: number; kpa: number; ve: number }>({
    rpm: 6500,
    kpa: 220,
    ve: 114.2,
  });

  return (
    <section id="showcase" className="relative py-24 bg-[#090A0D] border-t border-white/10 overflow-hidden">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-12">
          <div className="text-right max-w-2xl">
            <div className="inline-flex items-center gap-2 rounded-full bg-[#14161D] border border-white/12 px-3.5 py-1 text-xs font-telemetry font-bold text-amber-400 mb-3">
              <Activity className="h-3.5 w-3.5" />
              <span>معمل الهندسة التفاعلي (INTERACTIVE POWERTRAIN STUDIO)</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-heading tracking-tight">
              تشريح المحرك وخريطة كفاءة الحجم (VE Table)
            </h2>
            <p className="text-gray-400 text-base sm:text-lg mt-2">
              اضغط على نقاط التشريح التفاعلية لاستكشاف التفاوتات الميكانيكية، أو انتقل لجدول كفاءة الاحتراق الحي في الـ ECU:
            </p>
          </div>

          {/* Mode Switcher Buttons */}
          <div className="flex items-center gap-2 bg-[#14161D] p-1.5 rounded-xl border border-white/12 self-start lg:self-auto">
            <button
              onClick={() => setActiveTab('cutaway')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs sm:text-sm font-bold transition-all ${
                activeTab === 'cutaway'
                  ? 'bg-[#E60012] text-white shadow-lg shadow-[#E60012]/30'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Layers className="h-4 w-4" />
              <span>تشريح المحرك التفاعلي 3D</span>
            </button>
            <button
              onClick={() => setActiveTab('ve-table')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs sm:text-sm font-bold transition-all ${
                activeTab === 've-table'
                  ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/25'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Cpu className="h-4 w-4" />
              <span>خريطة الـ ECU (VE Table Live)</span>
            </button>
          </div>
        </div>

        {/* TAB 1: ENGINE CUTAWAY HOTSPOT BLUEPRINT EXPLORER */}
        {activeTab === 'cutaway' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left: Cutaway Image with Pulsing Hotspots */}
            <div className="lg:col-span-7 relative rounded-2xl bg-[#14161D] border border-white/15 overflow-hidden shadow-2xl group">
              <div className="relative aspect-[16/10] w-full">
                <img
                  src="/images/engine-twin-turbo.jpg"
                  alt="Twin Turbo V8 Engine Cutaway"
                  className="w-full h-full object-cover object-center scale-102 group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#090A0D] via-transparent to-transparent opacity-70" />
                {/* Blueprint CAD Grid Overlay */}
                <div className="absolute inset-0 bg-carbon-weave opacity-25 pointer-events-none" />

                {/* Hotspot Pulsing Buttons */}
                {ENGINE_HOTSPOTS.map((hotspot) => {
                  const isSelected = selectedHotspot.id === hotspot.id;
                  return (
                    <button
                      key={hotspot.id}
                      onClick={() => setSelectedHotspot(hotspot)}
                      style={{ left: `${hotspot.xPos}%`, top: `${hotspot.yPos}%` }}
                      className={`absolute -translate-x-1/2 -translate-y-1/2 z-20 flex h-10 w-10 items-center justify-center rounded-full transition-all duration-300 ${
                        isSelected
                          ? 'bg-[#E60012] text-white scale-125 ring-4 ring-[#E60012]/40 shadow-xl shadow-[#E60012]/60'
                          : 'bg-[#14161D]/90 text-amber-400 border border-white/30 hover:scale-110'
                      }`}
                      aria-label={hotspot.title}
                    >
                      <span className="font-telemetry font-extrabold text-xs">
                        0{hotspot.id}
                      </span>
                      {isSelected && (
                        <span className="absolute -inset-1.5 rounded-full border border-[#E60012] animate-ping" />
                      )}
                    </button>
                  );
                })}

                {/* Bottom Left HUD Tag */}
                <div className="absolute bottom-4 right-4 z-10 bg-[#090A0D]/90 border border-white/15 px-3.5 py-1.5 rounded-xl backdrop-blur-md flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-[#E60012] animate-pulse" />
                  <span className="text-xs font-telemetry text-white font-bold">
                    CAD INSPECTION MODE: 4.0L BITURBO V8
                  </span>
                </div>
              </div>
            </div>

            {/* Right: Selected Hotspot Telemetry Detail Card */}
            <div className="lg:col-span-5">
              <div className="rounded-2xl bg-[#14161D] border border-[#E60012]/40 p-6 sm:p-7 shadow-2xl glow-crimson-sm space-y-5 text-right">
                <div className="flex items-center justify-between border-b border-white/10 pb-4">
                  <div className="flex items-center gap-2.5">
                    <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#E60012] text-white font-telemetry font-bold text-sm">
                      0{selectedHotspot.id}
                    </span>
                    <span className="text-xs font-telemetry text-amber-400 font-bold">
                      {selectedHotspot.specCode}
                    </span>
                  </div>
                  <Maximize2 className="h-4 w-4 text-gray-400" />
                </div>

                <div>
                  <h3 className="text-xl sm:text-2xl font-bold text-white font-heading leading-tight">
                    {selectedHotspot.title}
                  </h3>
                  <p className="text-xs font-telemetry text-gray-400 mt-1">
                    {selectedHotspot.engTitle}
                  </p>
                </div>

                <p className="text-sm text-gray-300 leading-relaxed bg-[#090A0D]/70 p-4 rounded-xl border border-white/10">
                  {selectedHotspot.description}
                </p>

                {/* Technical Engineering Specifications List */}
                <div className="space-y-2.5">
                  <div className="p-3 rounded-xl bg-white/[0.03] border border-white/8 flex items-center justify-between text-xs">
                    <span className="text-gray-400">سبيكة المعدن (Material Spec):</span>
                    <span className="font-telemetry font-bold text-white">
                      {selectedHotspot.material}
                    </span>
                  </div>
                  <div className="p-3 rounded-xl bg-white/[0.03] border border-white/8 flex items-center justify-between text-xs">
                    <span className="text-gray-400">الإجهاد الحراري / الميكانيكي الأقصى:</span>
                    <span className="font-telemetry font-bold text-amber-400">
                      {selectedHotspot.maxStress}
                    </span>
                  </div>
                  <div className="p-3 rounded-xl bg-[#E60012]/10 border border-[#E60012]/30 flex items-center justify-between text-xs">
                    <span className="text-gray-200 font-bold">عزم الربط / ضغط التشغيل:</span>
                    <span className="font-telemetry font-extrabold text-[#E60012]">
                      {selectedHotspot.torqueOrBoost}
                    </span>
                  </div>
                </div>

                {/* Hotspot Switcher Row */}
                <div className="pt-2 flex items-center justify-between gap-2">
                  <span className="text-xs text-gray-400">انقر نقطة أخرى للفحص:</span>
                  <div className="flex items-center gap-1.5">
                    {ENGINE_HOTSPOTS.map((h) => (
                      <button
                        key={h.id}
                        onClick={() => setSelectedHotspot(h)}
                        className={`h-8 w-8 rounded-lg font-telemetry text-xs font-bold transition-all ${
                          selectedHotspot.id === h.id
                            ? 'bg-[#E60012] text-white'
                            : 'bg-white/5 text-gray-400 hover:text-white'
                        }`}
                      >
                        0{h.id}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: LIVE ECU VOLUMETRIC EFFICIENCY (VE TABLE) TUNER */}
        {activeTab === 've-table' && (
          <div className="rounded-2xl bg-[#14161D] border border-white/15 p-6 sm:p-8 shadow-2xl">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-4 border-b border-white/10">
              <div>
                <div className="flex items-center gap-2">
                  <span className="h-2.5 w-2.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-xs font-telemetry font-bold text-emerald-400">
                    MOTEC M150 STANDALONE ECU LIVE MAP
                  </span>
                </div>
                <h3 className="text-xl font-bold text-white font-heading mt-1">
                  جدول كفاءة الحجم (Volumetric Efficiency %) — اضغط على أي خلية لفحص حقن الوقود
                </h3>
              </div>

              {/* Selected Cell Live Callout */}
              <div className="flex items-center gap-3 bg-[#090A0D] px-4 py-2.5 rounded-xl border border-white/12">
                <div>
                  <div className="text-[10px] text-gray-400 font-telemetry">خلية المعايرة النشطة</div>
                  <div className="text-sm font-telemetry font-bold text-amber-400">
                    RPM: {selectedVeCell.rpm} | BOOST: {selectedVeCell.kpa} kPa
                  </div>
                </div>
                <div className="px-2.5 py-1 rounded bg-[#E60012] text-white font-telemetry font-bold text-sm">
                  {selectedVeCell.ve}% VE
                </div>
              </div>
            </div>

            {/* Interactive Grid Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-center font-telemetry text-xs border-collapse">
                <thead>
                  <tr className="border-b border-white/10 text-gray-400">
                    <th className="py-2.5 px-3 text-right bg-[#090A0D] rounded-tr-lg">
                      MAP kPa \ RPM
                    </th>
                    {[2000, 3500, 4800, 6000, 7200, 8400, 9000].map((r) => (
                      <th key={r} className="py-2.5 px-3 bg-[#090A0D] text-amber-400">
                        {r}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {[
                    { kpa: 40, values: [58.2, 64.1, 68.4, 71.0, 69.8, 65.2, 62.0] },
                    { kpa: 100, values: [88.5, 96.2, 101.4, 104.8, 103.2, 99.1, 95.4] },
                    { kpa: 160, values: [94.0, 106.8, 112.5, 115.0, 114.2, 111.0, 107.5] },
                    { kpa: 220, values: [99.5, 114.0, 121.8, 126.4, 124.8, 121.2, 117.8] },
                    { kpa: 280, values: [104.2, 120.5, 129.2, 134.8, 133.0, 129.4, 125.6] },
                  ].map((row) => (
                    <tr key={row.kpa} className="border-b border-white/8 hover:bg-white/[0.02]">
                      <td className="py-2.5 px-3 text-right font-bold text-gray-300 bg-[#090A0D]/60">
                        {row.kpa} kPa ({((row.kpa - 100) * 0.145).toFixed(1)} PSI)
                      </td>
                      {row.values.map((veVal, idx) => {
                        const rpms = [2000, 3500, 4800, 6000, 7200, 8400, 9000];
                        const isChosen =
                          selectedVeCell.rpm === rpms[idx] && selectedVeCell.kpa === row.kpa;
                        // Color intensity based on VE value
                        const cellBg =
                          veVal > 125
                            ? 'bg-[#E60012]/35 text-white font-bold'
                            : veVal > 105
                            ? 'bg-amber-500/25 text-amber-300'
                            : 'bg-white/5 text-gray-300';
                        return (
                          <td key={idx} className="p-1">
                            <button
                              onClick={() =>
                                setSelectedVeCell({ rpm: rpms[idx], kpa: row.kpa, ve: veVal })
                              }
                              className={`w-full py-2 px-2.5 rounded-lg transition-all ${cellBg} ${
                                isChosen
                                  ? 'ring-2 ring-[#E60012] bg-[#E60012] text-white scale-105 shadow-lg'
                                  : 'hover:scale-105'
                              }`}
                            >
                              {veVal}
                            </button>
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="mt-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-gray-400">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                تتضمن المنصة محاكي تعديل التوقيت (Ignition Timing Advance Table) ومراقبة طرق المحرك Knock Retard
              </span>
              <a
                href="#pricing"
                className="text-amber-400 hover:text-white font-bold inline-flex items-center gap-1"
              >
                احصل على حقيبة التعديل الاحترافية الآن ←
              </a>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
