import React, { useState, useEffect } from 'react';
import {
  Gauge,
  Volume2,
  VolumeX,
  Menu,
  X,
  Cpu,
  Sparkles,
  ChevronLeft,
} from 'lucide-react';
import { engineSound } from '../utils/engineSound';

interface NavbarProps {
  onOpenDiagnostic: (code?: string) => void;
  onOpenSignup: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenDiagnostic, onOpenSignup }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleEngineSound = () => {
    const nextState = !soundEnabled;
    setSoundEnabled(nextState);
    engineSound.setMuted(!nextState);
    if (nextState) {
      engineSound.revEngine(3800);
      setTimeout(() => engineSound.stopRev(), 450);
    }
  };

  const navLinks = [
    { label: 'القدرات والأدوات', href: '#features' },
    { label: 'تشريح المحرك التفاعلي', href: '#showcase' },
    { label: 'للهواة والمحترفين', href: '#benefits' },
    { label: 'تجارب الخبراء', href: '#testimonials' },
    { label: 'الباقات والأسعار', href: '#pricing' },
    { label: 'الأسئلة الشائعة', href: '#faq' },
  ];

  return (
    <header
      className={`fixed top-0 right-0 left-0 z-40 transition-all duration-300 ${
        scrolled
          ? 'bg-[#090A0D]/85 backdrop-blur-xl border-b border-white/10 shadow-2xl py-3.5'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Brand Logo & Telemetry Emblem */}
          <a
            href="#"
            className="flex items-center gap-3 group focus:outline-none"
            aria-label="الرئيسية أبِيكْس ميكانيكا"
          >
            <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-[#E60012] to-[#8C000B] text-white shadow-lg shadow-[#E60012]/30 group-hover:scale-105 transition-transform">
              <Gauge className="h-5 w-5 animate-pulse" />
              <span className="absolute -top-1 -left-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
            </div>
            <div className="flex flex-col">
              <span className="font-heading text-lg sm:text-xl font-extrabold tracking-tight text-white flex items-center gap-1.5">
                أبِيكْس ميكانيكا
                <span className="hidden sm:inline-block text-[10px] font-telemetry px-1.5 py-0.5 rounded bg-white/10 text-amber-400 border border-white/10">
                  APEX PRO
                </span>
              </span>
              <span className="text-[11px] text-gray-400 font-medium">
                كل ما يخص عالم السيارات وميكانيك الأداء الفائق
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="px-3.5 py-2 rounded-xl text-sm font-medium text-gray-300 hover:text-white hover:bg-white/5 transition-all"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Right Action Bar (Sound FX + DTC Quick Scanner + Primary CTA) */}
          <div className="hidden sm:flex items-center gap-2.5">
            {/* V8 Exhaust Sound Toggle */}
            <button
              onClick={toggleEngineSound}
              title={soundEnabled ? 'كتم صوت محاكي المحرك' : 'تفعيل صوت المحرك V8'}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-telemetry font-bold border transition-all ${
                soundEnabled
                  ? 'bg-amber-500/15 text-amber-400 border-amber-500/40 shadow-md shadow-amber-500/10'
                  : 'bg-white/5 text-gray-400 border-white/10 hover:text-white hover:border-white/20'
              }`}
            >
              {soundEnabled ? (
                <>
                  <Volume2 className="h-4 w-4 animate-pulse text-amber-400" />
                  <span>صوت V8: ON</span>
                </>
              ) : (
                <>
                  <VolumeX className="h-4 w-4" />
                  <span>صوت V8</span>
                </>
              )}
            </button>

            {/* OBD-II Quick Scan Modal Button */}
            <button
              onClick={() => onOpenDiagnostic('P0299')}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#14161D] border border-white/15 text-xs font-semibold text-gray-200 hover:border-[#E60012]/60 hover:text-white transition-all"
            >
              <Cpu className="h-4 w-4 text-[#E60012]" />
              <span>فحص كود OBD-II</span>
            </button>

            {/* Primary High-Conversion CTA */}
            <button
              onClick={onOpenSignup}
              className="relative inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#E60012] hover:bg-[#D00010] text-white text-xs sm:text-sm font-bold shadow-lg shadow-[#E60012]/30 hover:shadow-[#E60012]/50 transition-all active:scale-[0.98]"
            >
              <Sparkles className="h-4 w-4" />
              <span>ابدأ الآن مجاناً</span>
              <ChevronLeft className="h-4 w-4" />
            </button>
          </div>

          {/* Mobile Menu Toggle Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 border border-white/10 text-gray-300 hover:text-white"
            aria-label="القائمة الرئيسية"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden mt-3 mx-4 rounded-2xl bg-[#14161D]/98 border border-white/12 p-5 shadow-2xl backdrop-blur-xl animate-fadeIn">
          <div className="flex flex-col gap-2">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="px-4 py-2.5 rounded-xl text-sm font-semibold text-gray-200 hover:bg-white/10 transition-colors"
              >
                {link.label}
              </a>
            ))}
            <div className="h-px bg-white/10 my-2" />
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenDiagnostic('P0300');
                }}
                className="flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-white/5 border border-white/12 text-xs font-bold text-gray-200"
              >
                <Cpu className="h-4 w-4 text-[#E60012]" />
                محلل الأعطال OBD-II
              </button>
              <button
                onClick={() => {
                  toggleEngineSound();
                }}
                className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-white/5 border border-white/12 text-xs font-bold text-amber-400"
              >
                {soundEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                {soundEnabled ? 'صوت V8: شغال' : 'تفعيل صوت V8'}
              </button>
            </div>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenSignup();
              }}
              className="w-full mt-2 flex items-center justify-center gap-2 py-3 rounded-xl bg-[#E60012] text-white text-sm font-bold shadow-lg shadow-[#E60012]/30"
            >
              <span>جرّب المنصة الاحترافية مجاناً</span>
              <ChevronLeft className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
