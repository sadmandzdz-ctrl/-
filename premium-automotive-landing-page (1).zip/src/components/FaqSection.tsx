import React, { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: 'هل تدعم المنصة وصلات وأجهزة فحص OBD-II عبر البلوتوث والواي فاي؟',
      a: 'نعم بالتأكيد! تتوافق أبِيكْس ميكانيكا مع جميع أجهزة الفحص القياسية والاحترافية (OBDLink MX+, ELM327 v1.5, Autel MaxiSys, ThinkCar, Launch X431). يمكنك إدخال كود العطل مباشرة أو ربط تطبيق الموبايل لقراءة البث الحي Live Data Stream فوراً.',
    },
    {
      q: 'كيف تختلف مخططاتكم عن برامج الصيانة الأجنبية التقليدية مثل ALLDATA؟',
      a: 'أولاً: نقدم مخططات 3D تفاعلية معزولة بالألوان يمكنك تكبيرها وتدويرها بدلاً من صور PDF المسطحة القديمة. ثانياً: جميع شروح أكواد العطل وخطوات التتبع مدعومة باللغة العربية الهندسية الواضحة مع دمج المصطلحات المتداولة في ورش الخليج والعرب، بالإضافة لذكاء اصطناعي يقترح السبب الحقيقي وفق إحصائيات الأعطال الشائعة لكل محرك.',
    },
    {
      q: 'هل يمكن تشغيل المخططات وجداول عزم الربط بدون إنترنت (Offline Mode) في الورشة؟',
      a: 'نعم، باقات الميكانيكي المحترف ومركز الأداء تتيح لك تحميل حقيبة المحركات المفضلة (مثل محركات تويوتا لاندكروزر، بورش 911، بي إم دبليو M، وشيفروليه LS) للعمل أوفلاين بالكامل داخل الورش والقراجات تحت الأرض.',
    },
    {
      q: 'هل توجد فترة تجربة مجانية بدون التزام مالي؟',
      a: 'نعم، نوفر تجربة مجانية كاملة لمدة 14 يوماً تتيح لك الوصول لكاشف الأعطال الذكي، وعينات من المخططات التفاعلية 3D، وحاسبة الداينو. يمكنك الإلغاء بضغطة زر واحدة قبل انتهاء الـ 14 يوماً دون خصم هللة واحدة.',
    },
    {
      q: 'ما هي المحركات وسيارات الأداء الفائق التي تغطيها المنصة؟',
      a: 'نغطي أكثر من 2,500 محرك تشمل أساطير التعديل الياباني (2JZ-GTE, 1FZ-FE, VR38DETT, RB26DETT)، والهندسة الألمانية (Porsche 9A2/Mezger, BMW S58/S63/B58, Mercedes-AMG M177/M139)، والوحوش الأمريكية (LS3/LS7, Hellcat 6.2L Supercharged, Coyote 5.0L).',
    },
    {
      q: 'هل تترجمون المصطلحات الميكانيكية إلى اللهجات العربية الدارجة في الورش؟',
      a: 'نعم! إلى جانب المسمى العلمي المعتمد والمسمى الإنجليزي (مثل Crankshaft Position Sensor)، نوضح المرادف الشائع في الورش (حساس الكرنك / حساس عمود المرفق / بلف الحرارة / الثروتل بدي) لضمان تواصل سلس بين المهندس والفني وصاحب السيارة.',
    },
  ];

  return (
    <section id="faq" className="relative py-24 bg-[#090A0D] border-t border-white/10">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-14">
          <span className="inline-flex items-center gap-2 rounded-full bg-[#14161D] border border-white/12 px-3.5 py-1 text-xs font-telemetry font-bold text-amber-400 mb-3">
            <HelpCircle className="h-3.5 w-3.5" />
            <span>الأسئلة التقنية الشائعة (FAQ)</span>
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-heading">
            كل ما تحتاج معرفته عن منصة أبِيكْس ميكانيكا
          </h2>
        </div>

        <div className="space-y-3.5">
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className={`rounded-2xl border transition-all duration-300 ${
                  isOpen
                    ? 'bg-[#14161D] border-[#E60012]/50 shadow-lg'
                    : 'bg-[#14161D]/60 border-white/10 hover:border-white/20'
                }`}
              >
                <button
                  onClick={() => setOpenIndex(isOpen ? null : idx)}
                  className="w-full flex items-center justify-between gap-4 p-5 sm:p-6 text-right focus:outline-none"
                  aria-expanded={isOpen}
                >
                  <span className="text-base sm:text-lg font-bold text-white font-heading">
                    {faq.q}
                  </span>
                  <div
                    className={`flex h-8 w-8 items-center justify-center rounded-xl shrink-0 transition-transform duration-300 ${
                      isOpen
                        ? 'bg-[#E60012] text-white rotate-180'
                        : 'bg-white/5 text-gray-400'
                    }`}
                  >
                    <ChevronDown className="h-4 w-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 sm:px-6 pb-6 pt-1 text-sm sm:text-base text-gray-300 leading-relaxed border-t border-white/8">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
