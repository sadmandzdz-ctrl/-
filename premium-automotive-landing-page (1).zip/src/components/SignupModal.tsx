import React, { useState } from 'react';
import {
  X,
  Gauge,
  CheckCircle2,
  ShieldCheck,
  ChevronLeft,
} from 'lucide-react';

export interface SignupModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedPlan?: string;
}

export const SignupModal: React.FC<SignupModalProps> = ({
  isOpen,
  onClose,
  selectedPlan,
}) => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [userRole, setUserRole] = useState<'enthusiast' | 'pro' | 'garage'>('pro');
  const [favoriteEngine, setFavoriteEngine] = useState('Nissan VR38DETT / Porsche 9A2');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const handleReset = () => {
    setSubmitted(false);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-md animate-fadeIn"
      role="dialog"
      aria-modal="true"
    >
      <div className="relative w-full max-w-xl bg-[#14161D] border border-white/15 rounded-2xl shadow-2xl glow-crimson-sm overflow-hidden text-right">
        {/* Top Telemetry Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-[#090A0D]/80">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#E60012] text-white">
              <Gauge className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white font-heading">
                تفعيل تجربة أبِيكْس ميكانيكا الاحترافية (14 يوماً مجاناً)
              </h3>
              <p className="text-xs text-gray-400 font-telemetry">
                {selectedPlan ? `الباقة المختارة: ${selectedPlan}` : 'وصول فوري لكامل المخططات وأدوات التشخيص'}
              </p>
            </div>
          </div>
          <button
            onClick={handleReset}
            className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-gray-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {submitted ? (
          <div className="p-8 text-center space-y-5">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/15 border border-emerald-500/40 text-emerald-400">
              <CheckCircle2 className="h-9 w-9" />
            </div>
            <div>
              <span className="inline-block px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-400 font-telemetry text-xs font-bold mb-2">
                LICENSE ACTIVATED • ECU TELEMETRY READY
              </span>
              <h4 className="text-2xl font-bold text-white font-heading">
                مرحباً بك يا بطل في أبِيكْس ميكانيكا!
              </h4>
              <p className="text-sm text-gray-300 mt-2 max-w-md mx-auto leading-relaxed">
                تم تفعيل حسابك التجريبي بنجاح لمدة 14 يوماً. يمكنك الآن تصفح +45,000 كود عطل ومخطط 3D تفاعلي لمحرك {favoriteEngine}.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#090A0D] border border-white/10 text-xs font-telemetry text-amber-400 flex items-center justify-between">
              <span>رقم الترخيص التجريبي الفوري:</span>
              <span className="font-bold text-white">APEX-PRO-2026-{Math.floor(1000 + Math.random() * 9000)}</span>
            </div>

            <button
              onClick={handleReset}
              className="w-full py-3.5 rounded-xl bg-[#E60012] hover:bg-[#D00010] text-white font-bold text-sm transition-all shadow-lg shadow-[#E60012]/30"
            >
              دخول مباشر إلى غرفة تشخيص المحركات الآن
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-5">
            {/* Persona Role Selection */}
            <div>
              <label className="block text-xs font-bold text-gray-300 mb-2">
                ما هو اهتمامك الرئيسي بالمنصة؟
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'enthusiast', label: 'هاوي تعديل وسيارتي' },
                  { id: 'pro', label: 'ميكانيكي / مهندس فحص' },
                  { id: 'garage', label: 'صاحب مركز صيانة' },
                ].map((role) => (
                  <button
                    type="button"
                    key={role.id}
                    onClick={() => setUserRole(role.id as 'enthusiast' | 'pro' | 'garage')}
                    className={`py-2.5 px-2 rounded-xl text-xs font-bold transition-all border ${
                      userRole === role.id
                        ? 'bg-[#E60012] text-white border-[#E60012] shadow-md'
                        : 'bg-[#090A0D] text-gray-400 border-white/10 hover:text-white'
                    }`}
                  >
                    {role.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Inputs */}
            <div className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-gray-300 mb-1.5">
                  الاسم الكامل أو اسم مركز الصيانة
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="مثال: م. فهد الشمري / مركز أداء الخليج"
                  className="w-full rounded-xl bg-[#090A0D] border border-white/15 px-4 py-2.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#E60012]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-medium text-gray-300 mb-1.5">
                    البريد الإلكتروني
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="engineer@apexmechanica.com"
                    className="w-full rounded-xl bg-[#090A0D] border border-white/15 px-4 py-2.5 text-sm text-white placeholder-gray-500 font-telemetry focus:outline-none focus:border-[#E60012]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-300 mb-1.5">
                    رقم الواتساب (لتفعيل المخططات السريع)
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+966 50 XXX XXXX"
                    className="w-full rounded-xl bg-[#090A0D] border border-white/15 px-4 py-2.5 text-sm text-white placeholder-gray-500 font-telemetry focus:outline-none focus:border-[#E60012]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-300 mb-1.5">
                  محركك أو سيارتك المفضلة (لتجهيز المخططات الفورية)
                </label>
                <select
                  value={favoriteEngine}
                  onChange={(e) => setFavoriteEngine(e.target.value)}
                  className="w-full rounded-xl bg-[#090A0D] border border-white/15 px-4 py-2.5 text-sm text-white font-telemetry focus:outline-none focus:border-[#E60012]"
                >
                  <option value="Nissan VR38DETT / GT-R R35">Nissan VR38DETT / GT-R R35</option>
                  <option value="Toyota 2JZ-GTE / 1FZ-FE Land Cruiser">Toyota 2JZ-GTE / 1FZ-FE Land Cruiser</option>
                  <option value="Porsche 911 GT3 / 9A2 TwinTurbo">Porsche 911 GT3 / 9A2 TwinTurbo</option>
                  <option value="BMW M4 S58 / M5 S63 TwinTurbo">BMW M4 S58 / M5 S63 TwinTurbo</option>
                  <option value="Chevy LS3 / Hellcat 6.2L Supercharged">Chevy LS3 / Hellcat 6.2L Supercharged</option>
                  <option value="Mercedes-AMG M177 4.0L BiTurbo">Mercedes-AMG M177 4.0L BiTurbo</option>
                </select>
              </div>
            </div>

            {/* Trust badge */}
            <div className="flex items-center gap-2 text-xs text-gray-400 bg-white/[0.03] p-3 rounded-xl border border-white/8">
              <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0" />
              <span>تجربة مجانية كاملة 14 يوماً • لا يلزم إدخال بطاقة ائتمانية للبدء</span>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl bg-[#E60012] hover:bg-[#D00010] text-white font-bold text-sm transition-all shadow-lg shadow-[#E60012]/35 flex items-center justify-center gap-2"
            >
              <span>افتح منصة أبِيكْس ميكانيكا الآن</span>
              <ChevronLeft className="h-4 w-4" />
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
