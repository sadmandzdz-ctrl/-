import React, { useState } from 'react';
import {
  Check,
  Zap,
  Sparkles,
  TrendingUp,
  Calculator,
  ChevronLeft,
} from 'lucide-react';

interface PricingSectionProps {
  onOpenSignup: (planName?: string) => void;
}

export const PricingSection: React.FC<PricingSectionProps> = ({ onOpenSignup }) => {
  const [billingCycle, setBillingCycle] = useState<'annual' | 'monthly'>('annual');
  const [currency, setCurrency] = useState<'SAR' | 'USD'>('SAR');

  // Workshop ROI Calculator state
  const [carsPerMonth, setCarsPerMonth] = useState(65);
  // Estimate saving 45 minutes per vehicle = 0.75 hrs * cars * hourly workshop rate (180 SAR)
  const hoursSavedPerMonth = Math.round(carsPerMonth * 0.78);
  const moneySavedSar = hoursSavedPerMonth * 185;

  const currencySymbol = currency === 'SAR' ? 'ر.س' : '$';
  const convertPrice = (sarPrice: number) =>
    currency === 'SAR' ? sarPrice : Math.round(sarPrice / 3.75);

  const plans = [
    {
      id: 'enthusiast',
      name: 'باقة الهاوي (APEX ENTHUSIAST)',
      badge: 'لعشاق التعديل والصيانة الذاتية',
      monthlySar: 89,
      annualSar: 65,
      popular: false,
      features: [
        'تشخيص أكواد OBD-II بالذكاء الاصطناعي (غير محدود)',
        'دليل عزم الربط القياسي لأشهر 2,500 محرك',
        'مخططات التوربو والفاكيوم الأساسية 3D',
        'حاسبة قوة الداينو وفقدان مجموعة نقل الحركة WHP',
        'الوصول لمنتديات مجتمع مهندسي المحركات',
        'دعم فني عبر الدردشة الفورية 24/7',
      ],
      ctaText: 'ابدأ تجربتك المجانية 14 يوماً',
    },
    {
      id: 'pro',
      name: 'باقة الميكانيكي المحترف (PRO TECH)',
      badge: 'الأكثر طلباً للمهندسين والفنيين',
      monthlySar: 219,
      annualSar: 159,
      popular: true,
      features: [
        'جميع مزايا باقة الهاوي بالكامل',
        '+45,000 مخطط ضفائر وكهرباء أصلية (OEM Wiring & Pinouts)',
        'تشخيص شجرة أعطال شبكات CAN-Bus وFlexRay وLIN',
        'أمثلة موجات الأوسيلوسكوب المرجعية لكل حساس',
        'طباعة تقارير تشخيص رسمية بشعار ورشتك لعملائك',
        'إمكانية الاستخدام على 3 أجهزة (كمبيوتر + جوال + تابلت ورشة)',
        'تحديثات يومية لأحدث طرازات السيارات 2020-2026',
      ],
      ctaText: 'اشترك الآن في الباقة الاحترافية',
    },
    {
      id: 'garage',
      name: 'باقة مركز الأداء (RACE GARAGE ENTERPRISE)',
      badge: 'للمراكز وفِرَق السباقات متعددة الفنيين',
      monthlySar: 490,
      annualSar: 360,
      popular: false,
      features: [
        'جميع مزايا باقة الميكانيكي المحترف بالكامل',
        'رخص تشغيل لـ 10 مهندسين وفنيين في وقت واحد',
        'أرشيف خرائط الـ Standalone ECU (MoTeC, Haltech, Syvecs)',
        'تنزيل المخططات للعمل دون اتصال بالإنترنت (Offline Workshop Mode)',
        'مدير حساب هندسي مخصص للإجابة على المعضلات المستعصية',
        'خصم 35% على دورات أكاديمية أبِيكْس المعتمدة',
      ],
      ctaText: 'اطلب تفعيل مركز الصيانة',
    },
  ];

  return (
    <section id="pricing" className="relative py-24 bg-[#090A0D] border-t border-white/10 overflow-hidden">
      {/* Background glow */}
      <div className="pointer-events-none absolute top-1/4 right-1/4 h-96 w-96 rounded-full bg-[#E60012]/10 blur-[130px]" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="inline-flex items-center gap-2 rounded-full bg-[#14161D] border border-white/12 px-3.5 py-1 text-xs font-telemetry font-bold text-[#E60012] mb-3">
            <Sparkles className="h-3.5 w-3.5" />
            <span>استثمار هندسي يعوض قيمته من أول تشخيص ناجح</span>
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-heading tracking-tight">
            باقات شفافة تناسب{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-l from-[#E60012] to-amber-400">
              شغفك أو ورشتك
            </span>
          </h2>
          <p className="text-gray-400 text-base sm:text-lg mt-3">
            تجربة مجانية كاملة لمدة 14 يوماً بدون التزام، وإلغاء فوري بضغطة زر في أي وقت.
          </p>

          {/* Billing Cycle & Currency Switcher */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            {/* Billing Toggle */}
            <div className="inline-flex items-center p-1 rounded-xl bg-[#14161D] border border-white/15">
              <button
                onClick={() => setBillingCycle('annual')}
                className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-bold transition-all flex items-center gap-1.5 ${
                  billingCycle === 'annual'
                    ? 'bg-[#E60012] text-white shadow-md'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <span>اشتراك سنوي</span>
                <span className="px-1.5 py-0.5 rounded bg-amber-400 text-black text-[10px] font-telemetry font-extrabold">
                  خصم 27%
                </span>
              </button>
              <button
                onClick={() => setBillingCycle('monthly')}
                className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-bold transition-all ${
                  billingCycle === 'monthly'
                    ? 'bg-white/10 text-white'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                اشتراك شهري
              </button>
            </div>

            {/* Currency Selector */}
            <div className="inline-flex items-center p-1 rounded-xl bg-[#14161D] border border-white/15 text-xs font-telemetry font-bold">
              <button
                onClick={() => setCurrency('SAR')}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  currency === 'SAR' ? 'bg-white/15 text-amber-400' : 'text-gray-400'
                }`}
              >
                ر.س (SAR)
              </button>
              <button
                onClick={() => setCurrency('USD')}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  currency === 'USD' ? 'bg-white/15 text-amber-400' : 'text-gray-400'
                }`}
              >
                $ (USD)
              </button>
            </div>
          </div>
        </div>

        {/* 3 Pricing Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-7 items-stretch">
          {plans.map((plan) => {
            const price =
              billingCycle === 'annual'
                ? convertPrice(plan.annualSar)
                : convertPrice(plan.monthlySar);

            return (
              <div
                key={plan.id}
                className={`relative rounded-2xl flex flex-col justify-between transition-all duration-300 ${
                  plan.popular
                    ? 'bg-gradient-to-b from-[#181B24] to-[#14161D] border-2 border-[#E60012] shadow-2xl glow-crimson lg:-translate-y-2 p-8'
                    : 'bg-[#14161D]/80 border border-white/12 p-7 hover:border-white/25'
                }`}
              >
                {/* Popular Badge */}
                {plan.popular && (
                  <div className="absolute -top-3.5 right-6 px-4 py-1 rounded-full bg-gradient-to-l from-[#E60012] to-amber-500 text-white text-xs font-telemetry font-extrabold tracking-wide shadow-lg">
                    ★ الباقة الأكثر طلباً في الورش
                  </div>
                )}

                <div>
                  <div className="mb-4">
                    <span className="text-xs font-telemetry text-amber-400 font-bold block mb-1">
                      {plan.badge}
                    </span>
                    <h3 className="text-2xl font-bold text-white font-heading">
                      {plan.name}
                    </h3>
                  </div>

                  {/* Price Readout */}
                  <div className="flex items-baseline gap-1.5 my-6 pb-6 border-b border-white/10">
                    <span className="font-telemetry text-4xl sm:text-5xl font-extrabold text-white">
                      {price}
                    </span>
                    <span className="text-base font-bold text-amber-400">
                      {currencySymbol}
                    </span>
                    <span className="text-xs text-gray-400">
                      / شهرياً {billingCycle === 'annual' && '(يُفوتر سنوياً)'}
                    </span>
                  </div>

                  {/* Features List */}
                  <ul className="space-y-3.5 mb-8">
                    {plan.features.map((feat, i) => (
                      <li key={i} className="flex items-start gap-2.5 text-xs sm:text-sm text-gray-300">
                        <div className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-500/15 text-emerald-400 shrink-0 mt-0.5">
                          <Check className="h-3.5 w-3.5" />
                        </div>
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <button
                  onClick={() => onOpenSignup(plan.name)}
                  className={`w-full py-4 rounded-xl text-sm font-bold transition-all flex items-center justify-center gap-2 ${
                    plan.popular
                      ? 'bg-[#E60012] hover:bg-[#D00010] text-white shadow-lg shadow-[#E60012]/35 active:scale-[0.98]'
                      : 'bg-white/10 hover:bg-white/15 text-white border border-white/10'
                  }`}
                >
                  <Zap className="h-4 w-4" />
                  <span>{plan.ctaText}</span>
                  <ChevronLeft className="h-4 w-4" />
                </button>
              </div>
            );
          })}
        </div>

        {/* WORKSHOP ROI INTERACTIVE CALCULATOR */}
        <div className="mt-16 rounded-2xl bg-gradient-to-r from-[#14161D] via-[#1A1D27] to-[#14161D] border border-amber-500/30 p-6 sm:p-8 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-6 space-y-4 text-right">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 text-amber-400 font-telemetry text-xs font-bold border border-amber-500/30">
                <Calculator className="h-4 w-4" />
                WORKSHOP ROI SIMULATOR
              </div>
              <h3 className="text-2xl sm:text-3xl font-bold text-white font-heading">
                حاسبة العائد الاستثماري لورشتك شهرياً
              </h3>
              <p className="text-sm text-gray-300 leading-relaxed">
                حرك المؤشر بعدد السيارات التي تفحصها أو تصلحها ورشتك كل شهر، لترى كم ساعة عمل وأموال توفرها منصة أبِيكْس ميكانيكا بتفادي التخمين:
              </p>

              <div className="p-4 rounded-xl bg-[#090A0D] border border-white/10">
                <div className="flex justify-between text-xs font-telemetry mb-2">
                  <span className="text-gray-400">عدد السيارات في ورشتك شهرياً:</span>
                  <span className="text-amber-400 font-extrabold text-base">
                    {carsPerMonth} سيارة / شهر
                  </span>
                </div>
                <input
                  type="range"
                  min={15}
                  max={240}
                  step={5}
                  value={carsPerMonth}
                  onChange={(e) => setCarsPerMonth(Number(e.target.value))}
                  className="w-full h-3 bg-[#1F2430] rounded-lg appearance-none cursor-pointer accent-amber-500"
                  aria-label="عدد السيارات شهرياً"
                />
                <div className="flex justify-between text-[10px] text-gray-500 font-telemetry mt-1">
                  <span>15 سيارة (قراج خاص)</span>
                  <span>120 سيارة (مركز متوسط)</span>
                  <span>240 سيارة (مركز سباقات)</span>
                </div>
              </div>
            </div>

            {/* Results KPI Box */}
            <div className="lg:col-span-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-6 rounded-2xl bg-[#090A0D] border border-emerald-500/40 text-center flex flex-col justify-center">
                <div className="text-xs text-gray-400 font-telemetry uppercase mb-1">
                  ساعات العمل المهدرة التي ستوفرها
                </div>
                <div className="font-telemetry text-4xl font-extrabold text-emerald-400">
                  +{hoursSavedPerMonth} <span className="text-base text-white">ساعة</span>
                </div>
                <div className="text-[11px] text-gray-400 mt-2">
                  بمعدل توفير 47 دقيقة في كل تشخيص كود وتتبع سلك
                </div>
              </div>

              <div className="p-6 rounded-2xl bg-gradient-to-b from-[#E60012]/20 to-[#090A0D] border border-[#E60012]/40 text-center flex flex-col justify-center">
                <div className="text-xs text-gray-400 font-telemetry uppercase mb-1">
                  صافي التوفير الشهري المقدر لورشتك
                </div>
                <div className="font-telemetry text-4xl font-extrabold text-white">
                  {convertPrice(moneySavedSar).toLocaleString()}{' '}
                  <span className="text-base text-amber-400">{currencySymbol}</span>
                </div>
                <div className="text-[11px] text-emerald-400 font-bold mt-2 flex items-center justify-center gap-1">
                  <TrendingUp className="h-3.5 w-3.5" />
                  عائد يغطي اشتراك المنصة 120 ضعفاً
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
