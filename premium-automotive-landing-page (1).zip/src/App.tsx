import { useState } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { SocialProofSection } from './components/SocialProofSection';
import { BentoFeaturesSection } from './components/BentoFeaturesSection';
import { ProductShowcaseSection } from './components/ProductShowcaseSection';
import { BenefitsSection } from './components/BenefitsSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { PricingSection } from './components/PricingSection';
import { FaqSection } from './components/FaqSection';
import { FinalCtaSection } from './components/FinalCtaSection';
import { FooterSection } from './components/FooterSection';
import { DiagnosticModal } from './components/DiagnosticModal';
import { SignupModal } from './components/SignupModal';
import { Cpu } from 'lucide-react';

export function App() {
  const [diagnosticModalOpen, setDiagnosticModalOpen] = useState(false);
  const [selectedDtcCode, setSelectedDtcCode] = useState<string>('P0299');

  const [signupModalOpen, setSignupModalOpen] = useState(false);
  const [selectedSignupPlan, setSelectedSignupPlan] = useState<string | undefined>(undefined);

  const openDiagnosticWithCode = (code?: string) => {
    if (code) {
      setSelectedDtcCode(code);
    }
    setDiagnosticModalOpen(true);
  };

  const openSignupWithPlan = (planName?: string) => {
    setSelectedSignupPlan(planName);
    setSignupModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#090A0D] text-[#F3F4F6] selection:bg-[#E60012] selection:text-white relative">
      {/* Sticky Carbon Navigation Bar */}
      <Navbar
        onOpenDiagnostic={openDiagnosticWithCode}
        onOpenSignup={() => openSignupWithPlan()}
      />

      {/* Main Content Sections */}
      <main>
        <HeroSection
          onOpenDiagnostic={openDiagnosticWithCode}
          onOpenSignup={() => openSignupWithPlan()}
        />

        <SocialProofSection />

        <BentoFeaturesSection onOpenDiagnostic={openDiagnosticWithCode} />

        <ProductShowcaseSection />

        <BenefitsSection />

        <TestimonialsSection />

        <PricingSection onOpenSignup={openSignupWithPlan} />

        <FaqSection />

        <FinalCtaSection
          onOpenSignup={() => openSignupWithPlan()}
          onOpenDiagnostic={() => openDiagnosticWithCode('P0300')}
        />
      </main>

      {/* Precision Engineered Footer */}
      <FooterSection onOpenDiagnostic={openDiagnosticWithCode} />

      {/* Floating Quick OBD-II Scanner Pill Button */}
      <button
        onClick={() => openDiagnosticWithCode('P0299')}
        className="fixed bottom-6 left-6 z-40 hidden sm:flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-[#14161D]/95 border border-[#E60012]/60 text-white shadow-2xl glow-crimson-sm hover:scale-105 transition-all backdrop-blur-xl group"
        aria-label="افتح كاشف الأكواد الفوري OBD-II"
      >
        <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#E60012] text-white">
          <Cpu className="h-4 w-4 animate-pulse" />
        </span>
        <div className="text-right">
          <div className="text-xs font-bold font-heading group-hover:text-amber-400 transition-colors">
            كاشف الأكواد المباشر OBD-II
          </div>
          <div className="text-[10px] font-telemetry text-emerald-400">
            CAN-BUS SCANNER READY
          </div>
        </div>
      </button>

      {/* Interactive OBD-II & DTC Smart Diagnostic Modal */}
      <DiagnosticModal
        isOpen={diagnosticModalOpen}
        onClose={() => setDiagnosticModalOpen(false)}
        initialCode={selectedDtcCode}
      />

      {/* Interactive 14-Day Free Trial Registration Modal */}
      <SignupModal
        isOpen={signupModalOpen}
        onClose={() => setSignupModalOpen(false)}
        selectedPlan={selectedSignupPlan}
      />
    </div>
  );
}

export default App;
